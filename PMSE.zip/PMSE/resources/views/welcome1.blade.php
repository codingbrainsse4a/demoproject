@extends('layout.applayout')
@section('content')

<section class="home-banner with-border">
        <!--Banner Slider-->
        <div class="banner-slider-container">
            <ul class="banner-slider owl-theme owl-carousel">
                <li class="slide-item" style="background-image:url(assets/images/main-slider/1.jpg);"></li>
                <li class="slide-item" style="background-image:url(assets/images/main-slider/2.jpg);"></li>
                <li class="slide-item" style="background-image:url(assets/images/main-slider/3.jpg);"></li>
            </ul>
        </div>        
    </section>
    
    
    <!--Property Listing-->
    <section class="property-listing">
        <div class="auto-container">
            <div class="mixitup-gallery">
                <!--Heading-->
                <div class="sec-title centered">
                    <h2>Latest Properties</h2>
                </div>
                
                <!--Filter-->
                <div class="filters gallery-filters">
                    <ul class="filter-tabs filter-btns clearfix">
                        <li class="active filter" data-role="button" data-filter="all">Any Type</li>
                        <li class="filter" data-role="button" data-filter=".for-sell">For sale</li>
                        <li class="filter" data-role="button" data-filter=".for-rent">For Rent</li>
                    </ul>
                </div>
                
                <div class="filter-list row clearfix">

                @foreach($propertyinfor1 as $propertyinfor1)

                    <div class="default-property-box mix all for-rent col-lg-4 col-md-6 col-sm-6 col-xs-12">                   
                            <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><a href="{{URL('property-details/'.$propertyinfor1->property_slug)}}"><img src="{{url($propertyinfor1->getimg($propertyinfor1->id))}}" alt=""></a></figure>
                                <div class="property-price">${{$propertyinfor1->prices}} / Month</div>
                            </div>
                            <div class="lower-content">
                                <div class="rating-review">
                                    <div class="ratings"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></div>
                                    <div class="rev">(105 reviews)</div>
                                </div>
                                <div class="property-title">
                                    <h3><a href="{{URL('property-details/'.$propertyinfor1->property_slug)}}">{{$propertyinfor1->property_title}}</a></h3>
                                    <div class="location"><span class="fa fa-map-marker"></span>&nbsp; {{$propertyinfor1->property_location}},
                                    {{$propertyinfor1->city}}
                                    {{$propertyinfor1->state}}</div>
                                </div>
                                <div class="prop-info clearfix">
                                    <div class="prop-for"><span class="for">For {{$propertyinfor1->property_type}}</span><span class="area">{{$propertyinfor1->property_area}} sq ft.</span></div>
                                    <div class="link-box"><a href="{{URL('property-details/'.$propertyinfor1->property_slug)}}" class="theme-btn">View Details <span class="fa fa-angle-right"></span></a></div>
                                </div>
                                <div class="property-meta">
                                    <ul class="clearfix">
                                        <li><span class="icon fa fa-user"></span> {{$propertyinfor1->getName($propertyinfor1->user_id)}}</li>
                                        <li><span class="icon fa fa-calendar"></span> {{$propertyinfor1->created_at}}</li>
                                        <li class="options"><a href="#"><span class="fa fa-heart-o"></span></a> &ensp; <a href="#"><span class="fa fa-share-alt"></span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                    @endforeach
                    @foreach($propertyinfor as $propertyinfor)
                    <div class="default-property-box mix all for-sell col-lg-4 col-md-6 col-sm-6 col-xs-12">

                                          
                            <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><a href="{{URL('property-details/'.$propertyinfor->property_slug)}}"><img src="{{url($propertyinfor->getimg($propertyinfor->id))}}" alt=""></a></figure>
                                <div class="property-price">${{$propertyinfor->prices}} / Month</div>
                            </div>
                            <div class="lower-content">
                                <div class="rating-review">
                                    <div class="ratings"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></div>
                                    <div class="rev">(105 reviews)</div>
                                </div>
                                <div class="property-title">
                                    <h3><a href="{{URL('property-details/'.$propertyinfor->property_slug)}}">{{$propertyinfor->property_title}}</a></h3>
                                    <div class="location"><span class="fa fa-map-marker"></span>&nbsp; {{$propertyinfor->property_location}},
                                    {{$propertyinfor->city}}
                                    {{$propertyinfor->state}}</div>
                                </div>
                                <div class="prop-info clearfix">
                                    <div class="prop-for"><span class="for">For {{$propertyinfor->property_type}}</span><span class="area">{{$propertyinfor->property_area}} sq ft.</span></div>
                                    <div class="link-box"><a href="{{URL('property-details/'.$propertyinfor->property_slug)}}" class="theme-btn">View Details <span class="fa fa-angle-right"></span></a></div>
                                </div>
                                <div class="property-meta">
                                    <ul class="clearfix">
                                        <li><span class="icon fa fa-user"></span> {{$propertyinfor->getName($propertyinfor->user_id)}}</li>
                                        <li><span class="icon fa fa-calendar"></span> {{$propertyinfor->created_at}}</li>
                                        <li class="options"><a href="#"><span class="fa fa-heart-o"></span></a> &ensp; <a href="#"><span class="fa fa-share-alt"></span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                   
                    @endforeach
                </div>
            </div>            
            <div class="view-all"><a href="properties-list-one.html" class="theme-btn btn-style-two">Explore More Properties</a></div>
            
        </div>
    </section>
    
    
    <!--Popular Places-->
    <section class="popular-places">
        <div class="auto-container">
            <!--Heading-->
            <div class="sec-title centered">
                <h2>Popular Places</h2>
            </div>
          
            <div class="popular-place-carousel owl-theme owl-carousel">
                  @foreach($propertyinform as $propertyinform)
                <!--Popular Place Box--> 
                <div class="popular-place-box">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><img src="{{url($propertyinform1->getimg($propertyinform1->id))}}" alt=""></figure>
                            <div class="overlay-content">
                                <h4>{{$propertyinform->city}}</h4>
                                <div class="count">{{$count =\DB::table('property_information')->where('city',$propertyinform->city)->count('city')}}</div>
                            </div>
                        </div>
                        
                        <a href="{{URL('search-property-city-'.$propertyinform->city)}}" name="$propertyinform->city" class="link-overlay"></a>
                    </div>
                </div>
               
                <!--Popular Place Box-->
                 @endforeach
            </div>
           
        </div>
    </section>

    
    
    <!--Team Section-->
    <section class="team-section">
        <div class="auto-container">
            <!--Heading-->
            <div class="sec-title centered">
                <h2>Creative Agents</h2>
            </div>
            
            <div class="row clearfix">
                @foreach($user as $user)
          <div class="team-member col-md-6 col-sm-6 col-xs-12">
             
                    <div class="inner-box">
                    <div class="clearfix">
                            
                    <div class="image-column col-md-5 col-sm-12 col-xs-12">
                                
                    <figure class="image"><a href="">
                         
                        <img src="{{$user->getUserProfile->profile_image}}" alt=""></a>
          

                    </figure>
                          
                            </div>
                            <!--Content Column-->
                            <div class="content-column col-md-7 col-sm-12 col-xs-12">
                                <div class="inner">
                                    <div class="title">
                                        <h3><a href="agent-single.html">{{$user->firstname}} 
                                        {{$user->lastname}}</a></h3>
                                        <div class="designation">Property Manager @<a href="#">PMS</a></div>
                                        
                                    <div class="designation">Contact No.: {{$user->contactno}}</div>
                                    <div class="designation">Email Id: {{$user->email}}</div>
                                    </div>
                                    <div class="desc-text">Duis aute irure dolor in voccaecat reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla.</div>
                                    <div class="social-links">
                                        <ul class="clearfix">
                                            <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                            <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 @endforeach
            </div>
            
            <div class="view-all"><a href="agents.html" class="theme-btn btn-style-two">View More Agents</a></div>
            
        </div>
    </section>
    
    
    <!--Testimonials Section-->
    <section class="testimonials-style-one">
        <div class="auto-container">
            <!--Heading-->
            <div class="sec-title centered">
                <h2>Testimonials</h2>
            </div>
            
            <div class="carousel-outer">
                <div class="testimonial-carousel-one single-item-carousel owl-theme owl-carousel">
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                                <!--Image Column-->
                                <div class="image-column col-md-3 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                                <!--Content Column-->
                                <div class="content-column col-md-9 col-sm-12 col-xs-12">
                                    <div class="inner">
                                        <div class="icon"></div>
                                        <div class="slide-text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni.</div>
                                        <div class="author-info">
                                            <h4>Shah Paran</h4>
                                            <div class="designation">Company Agent @<a href="#">Reki Housing</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                                <!--Image Column-->
                                <div class="image-column col-md-3 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                                <!--Content Column-->
                                <div class="content-column col-md-9 col-sm-12 col-xs-12">
                                    <div class="inner">
                                        <div class="icon"></div>
                                        <div class="slide-text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni.</div>
                                        <div class="author-info">
                                            <h4>Shah Paran</h4>
                                            <div class="designation">Company Agent @<a href="#">Reki Housing</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                                <!--Image Column-->
                                <div class="image-column col-md-3 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                                <!--Content Column-->
                                <div class="content-column col-md-9 col-sm-12 col-xs-12">
                                    <div class="inner">
                                        <div class="icon"></div>
                                        <div class="slide-text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni.</div>
                                        <div class="author-info">
                                            <h4>Shah Paran</h4>
                                            <div class="designation">Company Agent @<a href="#">Reki Housing</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                                <!--Image Column-->
                                <div class="image-column col-md-3 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                                <!--Content Column-->
                                <div class="content-column col-md-9 col-sm-12 col-xs-12">
                                    <div class="inner">
                                        <div class="icon"></div>
                                        <div class="slide-text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni.</div>
                                        <div class="author-info">
                                            <h4>Shah Paran</h4>
                                            <div class="designation">Company Agent @<a href="#">Reki Housing</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                                <!--Image Column-->
                                <div class="image-column col-md-3 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                                <!--Content Column-->
                                <div class="content-column col-md-9 col-sm-12 col-xs-12">
                                    <div class="inner">
                                        <div class="icon"></div>
                                        <div class="slide-text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni.</div>
                                        <div class="author-info">
                                            <h4>Shah Paran</h4>
                                            <div class="designation">Company Agent @<a href="#">Reki Housing</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            
        </div>
    </section>
    
    
    <!--News Section-->
    <section class="news-section">
        <div class="auto-container">
            <!--Heading-->
            <div class="sec-title centered">
                <h2>Latest News</h2>
            </div>
            
            <div class="row clearfix">
                <!--News Style One-->
                <div class="news-style-one col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-1.jpg" alt=""></a></figure>
                        <div class="lower-content">
                            <div class="post-meta">
                                <ul>
                                    <li>Jonathan Doe  / 28 Feb 2017</li>
                                </ul>
                            </div>
                            <h3><a href="blog-details.html">Nemo enim ipsam voluptatem quia</a></h3>
                            <div class="text">Duis aute irure dolor in voccaecat reprehenderit in voluptate velit esse cillum dolore.</div>
                        </div>
                    </div>
                </div>
                <!--News Style One-->
                <div class="news-style-one col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-2.jpg" alt=""></a></figure>
                        <div class="lower-content">
                            <div class="post-meta">
                                <ul>
                                    <li>Jonathan Doe  / 28 Feb 2017</li>
                                </ul>
                            </div>
                            <h3><a href="blog-details.html">Voluptatem accusantium doloremque</a></h3>
                            <div class="text">Duis aute irure dolor in voccaecat reprehenderit in voluptate velit esse cillum dolore.</div>
                        </div>
                    </div>
                </div>
                <!--News Style One-->
                <div class="news-style-one col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-3.jpg" alt=""></a></figure>
                        <div class="lower-content">
                            <div class="post-meta">
                                <ul>
                                    <li>Jonathan Doe  / 28 Feb 2017</li>
                                </ul>
                            </div>
                            <h3><a href="blog-details.html">Excepteur sint occaecat cupidatat</a></h3>
                            <div class="text">Duis aute irure dolor in voccaecat reprehenderit in voluptate velit esse cillum dolore.</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="view-all"><a href="blog.html" class="theme-btn btn-style-two">View More News</a></div>
            
        </div>
    </section>
    
    
    <!--Sponsors Section-->
    <section class="sponsors-section">
        <div class="auto-container">
            <!--Heading-->
            <div class="sec-title centered">
                <h2>Our Partners</h2>
            </div>
            
            <ul class="sponsors-carousel owl-theme owl-carousel">
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/1.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/2.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/3.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/4.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/4.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/4.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/1.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/2.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/2.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/3.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/4.png" alt=""></a></figure></li>
            </ul>
            
        </div>
    </section>
    
    <!--NewsLetter Section-->
    <section class="newsletter-section with-negative-margin">
        <div class="auto-container">
            <div class="outer-box">
                <!--Heading-->
                <div class="sec-title centered">
                    <h2>Get Update</h2>
                </div>
                
                <!--Newsletter Style One-->
                <div class="newsletter-style-one">
                    <div class="desc-text">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia est deserunt mollit anim laborum. Sed perspiciatis unde omnis iste natus.</div>
                    
                    <form method="post" action="">
                        <div class="form-group">
                            <input type="email" name="text" value="" placeholder="Enter Your Email" required>
                            <button type="submit" class="theme-btn">Subscribe</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    @stop