    @extends('layout.applayout')
    @section('content')

     <section class="home-banner with-border">
<div class="banner-slider-container">
            <ul class="banner-slider owl-theme owl-carousel">
            <li class="slide-item" style="background-image:url(assets/images/main-slider/1.jpg);"></li>
            <li class="slide-item" style="background-image:url(assets/images/main-slider/2.jpg);"></li>
            <li class="slide-item" style="background-image:url(assets/images/main-slider/3.jpg);"></li>
            </ul>
        </div>
        
        <!--Banner Search Form-->
        <div class="banner-search-container">
            <div class="form-outer">
                <div class="banner-search-form">
                    <h1>Find your dream home just in a click</h1>
                    <div class="text">“Local Real Estate / Marketed Internationally”</div>
                    
                    <div class="banner-form-box">
                        <div class="default-form">
                            <form method="post" action="http://effortthemes.com/html/lirive/properties-list-one.html">
                                <div class="row clearfix">
                                    <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                        <select class="custom-select-box">
                                            <option>Property Type</option>
                                            <option>Residential</option>
                                            <option>Commercial</option>
                                            <option>Agriculture</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6 col-sm-4 col-xs-12">
                                        <input type="text" name="field-name" value="" placeholder="Enter Location" required>
                                    </div>
                                    <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                        <button type="submit" class="theme-btn btn-style-one">SEARCH</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>
    <!--Property Listing-->
    <section class="properties-search-section">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Posts Column-->
                <div class="posts-column col-lg-8 col-md-12 col-sm-12 col-xs-12">
                    <div class="upper-filters clearfix">
                        <!--Form Column-->
                        <div class="form-column">
                            <div class="default-form">
                                <form method="post" action="">
                                    <div class="option-box sort-by">
                                        <div class="sel-label">Sort By</div>
                                        <div class="form-group">
                                            <select class="custom-select-box">
                                                
                                                <option>Sale</option>
                                                <option>Rent</option>
                                            </select>
                                        </div>
                                    </div>
                                     <div class="option-box">
                                        <div class="sel-label">View</div>
                                        <div class="form-group">
                                            <select class="custom-select-box">
                                                <option>Grid</option>
                                                <option>List</option>
                                            </select>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!--Count Column-->
                        <div class="count-column">
                            <div class="count">42 homes found</div>
                        </div>
                        
                    </div>
                    
                    <div class="row clearfix">
                        <!--Default Property Box-->
                        @foreach($propertyinfo as $search_property)
                        <div class="default-property-box col-md-6 col-sm-6 col-xs-12">
                            <div class="inner-box">
                                <div class="image-box">
                                    <figure class="image"><a href=""><img src="{{url($search_property->getimg($search_property->id))}}" alt=""></a></figure>
                                    <div class="property-price">${{$search_property->prices}} / Month</div>
                                    <div class="property-tag">Coding Brains</div>
                                </div>
                                <div class="lower-content">
                                    <div class="rating-review">
                                        <div class="ratings"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></div>
                                        <div class="rev">(105 reviews)</div>
                                    </div>
                                    <div class="property-title">
                                        <h3><a href="">{{$search_property->property_title}}</a></h3>
                                        <div class="location"><span class="fa fa-map-marker"></span>&nbsp; {{$search_property->property_location}}</div>
                                    </div>
                                    <div class="prop-info clearfix">
                                        <div class="prop-for"><span class="for">For {{$search_property->property_type}}</span><span class="area">{{$search_property->property_area}} sq ft.</span></div>
                                        <div class="link-box"><a href="{{URL('property-details/'.$search_property->property_slug)}}" class="theme-btn">View Details 
                                        <span class="fa fa-angle-right">
                                        </span></a></div>
                                        
                                    </div>
                                    <div class="property-meta">
                                        <ul class="clearfix">
                                            <li><span class="icon fa fa-user"></span> {{$search_property->getName($search_property->user_id)}}</li>
                                            <li><span class="icon fa fa-calendar"></span> {{$search_property->created_at}}</li>
                                            <li class="options"><a href="#"><span class="fa fa-heart-o"></span></a> &ensp; <a href="#"><span class="fa fa-share-alt"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                       @endforeach
                         </div>
                        
                    <!-- Styled Pagination -->
                    <div class="styled-pagination">
                        <ul>
                            <li><a href="#" class="active">1</a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#" class="next">Next</a></li>
                        </ul>
                </div>                
            </div>
<div class="search-form-column col-lg-4 col-md-12 col-sm-12 col-xs-12">
                    <div class="form-box">
                        <div class="title-header">Advance Search</div>
                        
                        <div class="default-form">
                            <form method="post" action="http://effortthemes.com/html/lirive/agents.html">
                                <div class="row clearfix">
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="field-label">Status</div>
                                        <select class="custom-select-box">
                                            <option>Any Status</option>
                                            <option>For Rent</option>
                                            <option>For Sale</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                     <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                       <div class="range-slider-one">
                                            <div class="slider-header">
                                                <div class="clearfix">
                                                    <div class="title">Area Range (sq ft):</div>
                                                    <div class="input"><input type="text" class="area-size" name="field-name" readonly></div>
                                                </div>
                                            </div>
                                             
                                            <div class="area-range-slider"></div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="range-slider-one">
                                            <div class="slider-header">
                                                <div class="clearfix">
                                                    <div class="title">Price Range ($):</div>
                                                    <div class="input"><input type="text" class="property-amount" name="field-name" readonly></div>
                                                </div>
                                            </div>
                                             
                                            <div class="price-range-slider"></div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="field-label">Location</div>
                                        <select class="custom-select-box">
                                            <option>All Cities</option>
                                            <option>Ney York</option>
                                            <option>Hong Kong</option>
                                            <option>Islamabad</option>
                                            <option>Dhaka</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <div class="field-label">Beds</div>
                                        <select class="custom-select-box">
                                            <option>All</option>
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3-5</option>
                                            <option>5-10</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <div class="field-label">Baths</div>
                                        <select class="custom-select-box">
                                            <option>All</option>
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3-5</option>
                                            <option>5-10</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="field-label">Additional Features</div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-1">
                                            <label for="cbox-1">Swimming Pool</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-2">
                                            <label for="cbox-2">Air Conditioning</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-3">
                                            <label for="cbox-3">Laundry Room</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-4">
                                            <label for="cbox-4">Gym</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-5">
                                            <label for="cbox-5">Central Heating</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-6">
                                            <label for="cbox-6">Fire Safty</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-7">
                                            <label for="cbox-7">Window Cinvering</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-8">
                                            <label for="cbox-8">Alarm</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-9">
                                            <label for="cbox-9">Garden</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-10">
                                            <label for="cbox-10">Guest House</label>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <button type="submit" class="theme-btn btn-style-one">Search Filters</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    
                    </div>
                </div>
            </div>
    </div>
    </section>
  
















    <section class="property-listing">
        <div class="auto-container">
            <div class="mixitup-gallery">
                <!--Heading-->
                <div class="sec-title centered">
                    <h2>About US</h2>
                </div>
                <div id="main-wrapper">
                    <div class="row">

                         <div class="col-lg-3 col-md-6">
                                
                            <div class="panel info-box panel-white">
                                <div class="panel-body">
                                    <div class="info-box-stats">
                                        <p class="counter">{{$count = \DB::table('users')->count()}}</p>
                                        <span class="info-box-title">All User Count</span>
                                    </div>
                                    <div class="info-box-icon">
                                        <i class="icon-eye"></i>
                                    </div>
                                    <div class="info-box-progress">
                                        <div class="progress progress-xs progress-squared bs-n">
                                            <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        
                    <div class="col-lg-3 col-md-6">
                            <div class="panel info-box panel-white">
                                <div class="panel-body">
                                    <div class="info-box-stats">
                                        <p class="counter">{{$count = \DB::table('users')->where('user_type','=','1')->count()}}</p>
                                        <span class="info-box-title">Property Manager Count</span>
                                    </div>
                                    <div class="info-box-icon">
                                        <i class="icon-users"></i>
                                    </div>
                                    <div class="info-box-progress">
                                        <div class="progress progress-xs progress-squared bs-n">
                                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                           

                         <div class="col-lg-3 col-md-6">
                            <div class="panel info-box panel-white">
                                <div class="panel-body">
                                    <div class="info-box-stats">
                                        <p class="counter">{{$count = \DB::table('users')->where('user_type','=','2')->count()}}</p>
                                        <span class="info-box-title">Total Customer Count</span>
                                    </div>
                                    <div class="info-box-icon">
                                        <i class="icon-basket"></i>
                                    </div>
                                    <div class="info-box-progress">
                                        <div class="progress progress-xs progress-squared bs-n">
                                            <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                         <div class="col-lg-3 col-md-6">
                            <div class="panel info-box panel-white">
                                <div class="panel-body">
                                    <div class="info-box-stats">
                                        <p class="counter">{{$count = \DB::table('property_information')->count()}}</p>
                                        <span class="info-box-title">Total Property Count</span>
                                    </div>
                                    <div class="info-box-icon">
                                        <i class="icon-envelope"></i>
                                    </div>
                                    <div class="info-box-progress">
                                        <div class="progress progress-xs progress-squared bs-n">
                                            <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <div class="panel info-box panel-white">
                                <div class="panel-body">
                                    <div class="info-box-stats">
                                        <p class="counter">{{$count = \DB::table('property_information')->count('city')}}</p>
                                        <span class="info-box-title">Total Property City Count</span>
                                    </div>
                                    <div class="info-box-icon">
                                        <i class="icon-envelope"></i>
                                    </div>
                                    <div class="info-box-progress">
                                        <div class="progress progress-xs progress-squared bs-n">
                                            <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>            
            <div class="view-all"><a href="properties-list-one.html" class="theme-btn btn-style-two">Explore More Properties</a></div>
            
        </div>
    </section>
    
    
 <section class="popular-places">
        <div class="auto-container">
            <!--Heading-->
            <div class="sec-title centered">
                <h2>Popular Places</h2>
            </div>
          
            <div class="popular-place-carousel owl-theme owl-carousel">
                  @foreach($propertyinform as $propertyinform)
                <!--Popular Place Box--> 
                <div class="popular-place-box">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><img src="{{url($propertyinform1->getimg($propertyinform1->id))}}" alt=""></figure>
                            <div class="overlay-content">
                                <h4>{{$propertyinform->city}}</h4>
                                <div class="count">{{$count =\DB::table('property_information')->where('city',$propertyinform->city)->count('city')}}</div>
                            </div>
                        </div>
                        
                        <a href="{{URL('search-property-city/'.$propertyinform->city)}}" name="$propertyinform->city" class="link-overlay"></a>
                    </div>
                </div>
               
                <!--Popular Place Box-->
                 @endforeach
            </div>
           
        </div>
    </section>





    <section class="team-section">
        <div class="auto-container">
            <!--Heading-->
            <div class="sec-title centered">
                <h2>Creative Agents</h2>
            </div>
            
<div class="row clearfix">
                @foreach($users as $user)
          <div class="team-member col-md-6 col-sm-6 col-xs-12">
             
                    <div class="inner-box">
                    <div class="clearfix">
                            
                    <div class="image-column col-md-5 col-sm-12 col-xs-12">
                                
                    <figure class="image"><a href=""><img src="{{$user->getUserProfile->profile_image}}" alt=""></a></figure>
                          
                            </div>
                            <!--Content Column-->
                            <div class="content-column col-md-7 col-sm-12 col-xs-12">
                                <div class="inner">
                                    <div class="title">
                                        <h2>{{$user->id}} 
                                             </h2>
                                        <h3><a href="">{{$user->firstname}} 
                                        {{$user->firstname}}</a></h3>
                                        <div class="designation">Company Agent @<a href="#">Reki Housing</a></div>
                                    </div>
                                    <div class="desc-text">Duis aute irure dolor in voccaecat reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla.</div>
                                    <div class="social-links">
                                        <ul class="clearfix">
                                            <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                            <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 @endforeach
            </div>
            
            <div class="view-all"><a href="agents.html" class="theme-btn btn-style-two">View More Agents</a></div>
            
        </div>
    </section>
    
    
    
    <!--Testimonials Section-->
    <section class="testimonials-style-one">
        <div class="auto-container">
            <!--Heading-->
            <div class="sec-title centered">
                <h2>Testimonials</h2>
            </div>
            
            <div class="carousel-outer">
                <div class="testimonial-carousel-one single-item-carousel owl-theme owl-carousel">
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                                <!--Image Column-->
                                <div class="image-column col-md-3 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                                <!--Content Column-->
                                <div class="content-column col-md-9 col-sm-12 col-xs-12">
                                    <div class="inner">
                                        <div class="icon"></div>
                                        <div class="slide-text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni.</div>
                                        <div class="author-info">
                                            <h4>Shah Paran</h4>
                                            <div class="designation">Company Agent @<a href="#">Reki Housing</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                                <!--Image Column-->
                                <div class="image-column col-md-3 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                                <!--Content Column-->
                                <div class="content-column col-md-9 col-sm-12 col-xs-12">
                                    <div class="inner">
                                        <div class="icon"></div>
                                        <div class="slide-text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni.</div>
                                        <div class="author-info">
                                            <h4>Shah Paran</h4>
                                            <div class="designation">Company Agent @<a href="#">Reki Housing</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                                <!--Image Column-->
                                <div class="image-column col-md-3 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                                <!--Content Column-->
                                <div class="content-column col-md-9 col-sm-12 col-xs-12">
                                    <div class="inner">
                                        <div class="icon"></div>
                                        <div class="slide-text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni.</div>
                                        <div class="author-info">
                                            <h4>Shah Paran</h4>
                                            <div class="designation">Company Agent @<a href="#">Reki Housing</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                                <!--Image Column-->
                                <div class="image-column col-md-3 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                                <!--Content Column-->
                                <div class="content-column col-md-9 col-sm-12 col-xs-12">
                                    <div class="inner">
                                        <div class="icon"></div>
                                        <div class="slide-text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni.</div>
                                        <div class="author-info">
                                            <h4>Shah Paran</h4>
                                            <div class="designation">Company Agent @<a href="#">Reki Housing</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                                <!--Image Column-->
                                <div class="image-column col-md-3 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                                <!--Content Column-->
                                <div class="content-column col-md-9 col-sm-12 col-xs-12">
                                    <div class="inner">
                                        <div class="icon"></div>
                                        <div class="slide-text">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni.</div>
                                        <div class="author-info">
                                            <h4>Shah Paran</h4>
                                            <div class="designation">Company Agent @<a href="#">Reki Housing</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            
        </div>
    </section>
    
    
    <!--News Section-->
    <section class="news-section">
        <div class="auto-container">
            <!--Heading-->
            <div class="sec-title centered">
                <h2>Latest News</h2>
            </div>
            
            <div class="row clearfix">
                <!--News Style One-->
                <div class="news-style-one col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-1.jpg" alt=""></a></figure>
                        <div class="lower-content">
                            <div class="post-meta">
                                <ul>
                                    <li>Jonathan Doe  / 28 Feb 2017</li>
                                </ul>
                            </div>
                            <h3><a href="blog-details.html">Nemo enim ipsam voluptatem quia</a></h3>
                            <div class="text">Duis aute irure dolor in voccaecat reprehenderit in voluptate velit esse cillum dolore.</div>
                        </div>
                    </div>
                </div>
                <!--News Style One-->
                <div class="news-style-one col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-2.jpg" alt=""></a></figure>
                        <div class="lower-content">
                            <div class="post-meta">
                                <ul>
                                    <li>Jonathan Doe  / 28 Feb 2017</li>
                                </ul>
                            </div>
                            <h3><a href="blog-details.html">Voluptatem accusantium doloremque</a></h3>
                            <div class="text">Duis aute irure dolor in voccaecat reprehenderit in voluptate velit esse cillum dolore.</div>
                        </div>
                    </div>
                </div>
                <!--News Style One-->
                <div class="news-style-one col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-3.jpg" alt=""></a></figure>
                        <div class="lower-content">
                            <div class="post-meta">
                                <ul>
                                    <li>Jonathan Doe  / 28 Feb 2017</li>
                                </ul>
                            </div>
                            <h3><a href="blog-details.html">Excepteur sint occaecat cupidatat</a></h3>
                            <div class="text">Duis aute irure dolor in voccaecat reprehenderit in voluptate velit esse cillum dolore.</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="view-all"><a href="blog.html" class="theme-btn btn-style-two">View More News</a></div>
            
        </div>
    </section>
    
    
    <!--Sponsors Section-->
    <section class="sponsors-section">
        <div class="auto-container">
            <!--Heading-->
            <div class="sec-title centered">
                <h2>Our Partners</h2>
            </div>
            
            <ul class="sponsors-carousel owl-theme owl-carousel">
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/1.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/2.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/3.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/4.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/1.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/2.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/3.png" alt=""></a></figure></li>
                <li><figure class="image"><a href="#"><img src="assets/images/sponsors/4.png" alt=""></a></figure></li>
            </ul>
            
        </div>
    </section>
    
    <!--NewsLetter Section-->
    <section class="newsletter-section with-negative-margin">
        <div class="auto-container">
            <div class="outer-box">
                <!--Heading-->
                <div class="sec-title centered">
                    <h2>Get Update</h2>
                </div>
                
                <!--Newsletter Style One-->
                <div class="newsletter-style-one">
                    <div class="desc-text">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia est deserunt mollit anim laborum. Sed perspiciatis unde omnis iste natus.</div>
                    
                    <form method="post" action="http://effortthemes.com/html/lirive/contact.html">
                        <div class="form-group">
                            <input type="email" name="text" value="" placeholder="Enter Your Email" required>
                            <button type="submit" class="theme-btn">Subscribe</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    @stop