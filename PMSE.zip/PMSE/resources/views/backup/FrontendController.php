<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\ContactUs;
use App\User;
use DB;
use App\Quotation;



class FrontendController extends Controller

{
public function aboutUs(Request $request)
    {
      $informationget['users'] = \App\User::where('user_type','=','1')->with('getUserProfile')->get();
      //dd($informationget);
      $informationget['propertyinform'] = \App\PropertyInformation::distinct('city')->get('city');
      $informationget['propertyinform1'] = \App\PropertyInformation::first();
//dd($informationget);
      if(\Auth::check()){
      $informationget['profileimage']= \App\UsersProfile::where('user_id',\Auth::user()->id)->first();
      return view('aboutus',$informationget);
    }else{
      return view('aboutus',$informationget);
}
}



   public function contactUs()
    {
    	if(\Auth::check()){
    	$profileimg= \App\UsersProfile::where('user_id',\Auth::user()->id)->first();
      return view('contactus',['profileimage'=>$profileimg]);
    }else{
			return view('contactus');
}
}

   public function storecontact(Request $request)
   {
   	$validator=Validator::make($request->all(),[
              'name'       =>'required',
              'email_id'   =>'required|email|unique:contact_us',
              'contact_no' =>'min:10|max:10',
              'message'    =>'required',
              'subject'    => 'required',
   	]
   );
   	if($validator->fails()){
        return redirect()->back()->withErrors($validator)->withInput();
   }else{
   	   $contactus = new ContactUs();
   	   $contactus->name = $request->name;
       $contactus->subject = $request->subject;
       $contactus->message = $request->message;
       $contactus->contact_no = $request->contact_no;
       $contactus->email_id = $request->email_id;

       $contactus->save();
                    
  return redirect()->back()->with('success','Thank you!'.' '.$request->name.' '.'Your message has been successfully sent. We will contact you very soon!');
   }
}
       public function donecontactus()
          {
        return view('contactus');
          }

}
