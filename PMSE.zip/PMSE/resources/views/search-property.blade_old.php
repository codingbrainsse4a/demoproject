 @extends('layout.applayout')
    @section('content')
    
    
    <!--Inner Page Banner-->
    <section class="inner-page-banner style-two" style="background-image:url(assets/images/background/bg-page-title.jpg);">
        <div class="auto-container">
            <h1>Search Property</h1>
            <div class="text">Duis aute irure dolor in reprehenderit</div>
        </div>
    </section>
    <section class="register-section">
        <div class="auto-container">
            <div class="row clearfix">
    <div class="banner-search-container">
            <div class="form-outer">
                <div class="banner-search-form">
                <h1>Find your dream home just in a click</h1>
                <div class="text">“Local Real Estate / Marketed Internationally”</div>
                    
                    <div class="banner-form-box">
                        <div class="default-form">
                            <form method="post" action="http://effortthemes.com/html/lirive/properties-list-one.html">
                                <div class="row clearfix">
                                    <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                        <select class="custom-select-box">
                                            <option>Property Type</option>
                                            <option>Residential</option>
                                            <option>Commercial</option>
                                            <option>Agriculture</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6 col-sm-4 col-xs-12">
                                        <input type="text" name="field-name" value="" placeholder="Enter Location" required>
                                    </div>
                                    <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                        <button type="submit" class="theme-btn btn-style-one">SEARCH</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
           <section class="property-listing">
             @foreach($propertyinfo as $search_property)
              <div class="form-column column col-lg-6 col-md-6 col-sm-12 col-xs-12">
                  <div class="default-property-box list-view">
                            <div class="inner-box clearfix">
                                <!--Image Column-->
                                <div class="image-column col-md-6 col-sm-6 col-xs-12">
                                    <div class="image-box">
                                        <figure class="image"><a href="property-details.html"><img src="{{url($search_property->getimg($search_property->id))}}" alt=""></a></figure>
                                        <div class="property-price">${{$search_property->prices}}</div>
                                    </div>
                                </div>
                                <!--Content Column-->
                                <div class="content-column col-md-6 col-sm-6 col-xs-12">
                                    <div class="lower-content">
                                        <div class="rating-review">
                                            <div class="ratings"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></div>
                                            <div class="rev">(105 reviews)</div>
                                        </div>
                                        <div class="property-title">
                                            <h3><a href="property-details.html">{{$search_property->property_title}}</a></h3>
                                            <div class="location"><span class="fa fa-map-marker"></span>&nbsp; {{$search_property->property_location}}</div>
                                        </div>
                                        <div class="prop-info clearfix">
                                            <div class="prop-for"><span class="for">{{$search_property->property_type}}</span><span class="area">{{$search_property->property_area}}sq. ft</span></div>
                                            <div class="link-box"><a href="{{URL('property_details/'.$search_property->property_title)}} class="theme-btn">View Details <span class="fa fa-angle-right"></span></a></div>
                                        </div>
                                        <div class="property-meta">
                                            <ul class="clearfix">
                                                <li><span class="icon fa fa-user"></span> {{$search_property->getName($search_property->user_id)}}</li>
                                                <li><span class="icon fa fa-calendar"></span> {{$search_property->created_at}}</li>
                                                <li class="options"><a href="#"><span class="fa fa-heart-o"></span></a> &ensp; <a href="#"><span class="fa fa-share-alt"></span></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

              </div>
         @endforeach

         </section>
           </div>
               
            </div>
        </div>
    </section>
    
    @stop