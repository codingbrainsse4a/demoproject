    @extends('layout.applayout')
    @section('content')
    
    <!--Inner Page Banner-->
    <section class="inner-page-banner" style="background-image:url(assets/images/background/bg-page-title.jpg);">
        <div class="auto-container">
            <h1>Search Your Property</h1>
            <div class="text">“Local Real Estate / Marketed Internationally”</div>
            
            <div class="banner-form-box medium">
                <div class="default-form">
                    <form method="get" action="search-property" role="serach">
                        <div class="row clearfix">
                            <div class="form-group col-md-9 col-sm-8 col-xs-12">
                                <input type="text" name="q" value="" placeholder="Enter Location" required>
                            </div>
                            <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                <button type="submit" class="theme-btn btn-style-one">SEARCH</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
        </div>
    </section>
    
    
    <!--Properties Search Section-->
    <section class="properties-search-section">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Posts Column-->
                <div class="posts-column col-lg-8 col-md-12 col-sm-12 col-xs-12">
                    <div class="upper-filters clearfix">
                        <!--Form Column-->
                        <div class="form-column">
                            <div class="default-form">
                                <form method="post" action="">
                                	<div class="option-box sort-by">
                                        <div class="sel-label">Sort By</div>
                                        <div class="form-group">
                                            <select class="custom-select-box">
                                                
                                                <option>Sale</option>
                                                <option>Rent</option>
                                            </select>
                                        </div>
                                    </div>
                                     <div class="option-box">
                                        <div class="sel-label">View</div>
                                        <div class="form-group">
                                            <select class="custom-select-box">
                                                <option>Grid</option>
                                                <option>List</option>
                                            </select>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!--Count Column-->
                        <div class="count-column">
                            <div class="count">42 homes found</div>
                        </div>
                        
                    </div>
                    
                    <div class="row clearfix">
                    	<!--Default Property Box-->
                        @foreach($propertyinfo as $search_property)
                        <div class="default-property-box col-md-6 col-sm-6 col-xs-12">
                            <div class="inner-box">
                                <div class="image-box">
                                    <figure class="image"><a href=""><img src="{{url($search_property->getimg($search_property->id))}}" alt=""></a></figure>
                                    <div class="property-price">${{$search_property->prices}} / Month</div>
                                    <div class="property-tag">Coding Brains</div>
                                </div>
                                <div class="lower-content">
                                    <div class="rating-review">
                                        <div class="ratings"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></div>
                                        <div class="rev">(105 reviews)</div>
                                    </div>
                                    <div class="property-title">
                                        <h3><a href="">{{$search_property->property_title}}</a></h3>
                                        <div class="location"><span class="fa fa-map-marker"></span>&nbsp; {{$search_property->property_location}}</div>
                                    </div>
                                    <div class="prop-info clearfix">
                                        <div class="prop-for"><span class="for">For {{$search_property->property_type}}</span><span class="area">{{$search_property->property_area}} sq ft.</span></div>
                                        <div class="link-box"><a href="{{URL('property-details/'.$search_property->property_slug)}}" class="theme-btn">View Details 
                                        <span class="fa fa-angle-right">
                                        </span></a></div>
                                        
                                    </div>
                                    <div class="property-meta">
                                        <ul class="clearfix">
                                            <li><span class="icon fa fa-user"></span> {{$search_property->getName($search_property->user_id)}}</li>
                                            <li><span class="icon fa fa-calendar"></span> {{$search_property->created_at}}</li>
                                            <li class="options"><a href="#"><span class="fa fa-heart-o"></span></a> &ensp; <a href="#"><span class="fa fa-share-alt"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                       @endforeach
                         </div>
                        
                    <!-- Styled Pagination -->
                    <div class="styled-pagination">
                        <ul>
                            <li><a href="#" class="active">1</a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#" class="next">Next</a></li>
                        </ul>
                </div>                
        	</div>
<div class="search-form-column col-lg-4 col-md-12 col-sm-12 col-xs-12">
                    <div class="form-box">
                        <div class="title-header">Advance Search</div>
                        
                        <div class="default-form">
                            <form method="post" action="http://effortthemes.com/html/lirive/agents.html">
                                <div class="row clearfix">
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="field-label">Status</div>
                                        <select name="Propertytype" class="custom-select-box">
                                            <option>Select</option>
                                            <option value="Rent">For Rent</option>
                                            <option value="Sale">For Sale</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                     <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                       <div class="range-slider-one">
                                            <div class="slider-header">
                                                <div class="clearfix">
                                                    <div class="title">Area Range (sq ft):</div>
                                                    <div class="input"><input type="text" class="area-size" name="field-name" readonly></div>
                                                </div>
                                            </div>
                                             
                                            <div class="area-range-slider"></div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="range-slider-one">
                                            <div class="slider-header">
                                                <div class="clearfix">
                                                    <div class="title">Price Range ($):</div>
                                                    <div class="input"><input type="text" class="property-amount" name="field-name" readonly></div>
                                                </div>
                                            </div>
                                             
                                            <div class="price-range-slider"></div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="field-label">Location</div>
                                        <select class="custom-select-box">
                                            <option>All Cities</option>
                                            <option>Ney York</option>
                                            <option>Hong Kong</option>
                                            <option>Islamabad</option>
                                            <option>Dhaka</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <div class="field-label">Beds</div>
                                        <select class="custom-select-box">
                                            <option>All</option>
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3-5</option>
                                            <option>5-10</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <div class="field-label">Baths</div>
                                        <select class="custom-select-box">
                                            <option>All</option>
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3-5</option>
                                            <option>5-10</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="field-label">Additional Features</div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-1">
                                            <label for="cbox-1">Swimming Pool</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-2">
                                            <label for="cbox-2">Air Conditioning</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-3">
                                            <label for="cbox-3">Laundry Room</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-4">
                                            <label for="cbox-4">Gym</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-5">
                                            <label for="cbox-5">Central Heating</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-6">
                                            <label for="cbox-6">Fire Safty</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-7">
                                            <label for="cbox-7">Window Cinvering</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-8">
                                            <label for="cbox-8">Alarm</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-9">
                                            <label for="cbox-9">Garden</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-10">
                                            <label for="cbox-10">Guest House</label>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <button type="submit" class="theme-btn btn-style-one">Search Filters</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    
                    </div>
                </div>
            </div>
    </div>
    </section>
  
@stop