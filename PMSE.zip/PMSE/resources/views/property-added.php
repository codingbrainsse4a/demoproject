 @extends('layout.applayout')
    @section('content')
    <section class="inner-page-banner style-two" style="background-image:url(assets/images/background/bg-page-title.jpg);">
        <div class="auto-container">
            <h1>Submit Property</h1>
            <div class="text">Reprehenderit in voluptate velit esse cillum dolore.</div>
        </div>
    </section>
    
    <!--Add Property Section-->
    <section class="add-property">
    	

            

                 {{ csrf_field() }}
                <!--Add Property Info-->
                <div class="add-property-info">
                    <div class="auto-container">

                @if(Session::has('success'))
                <div class="alert alert-success">
                    {{ Session::get('success') }}
                </div>


                            @endif

                                @if (Session::has('error'))
                                 <div class="alert alert-danger">
                                {{Session::get('error')}}
                            </div>
                                @endif

</div>

  </div>
    </section>
    
    
   @stop