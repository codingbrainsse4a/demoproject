    @extends('layout.applayout')
    @section('content')

     <section class="home-banner with-border">
<div class="banner-slider-container">
            <ul class="banner-slider owl-theme owl-carousel">
            <li class="slide-item" style="background-image:url(assets/images/main-slider/1.jpg);"></li>
            <li class="slide-item" style="background-image:url(assets/images/main-slider/2.jpg);"></li>
            <li class="slide-item" style="background-image:url(assets/images/main-slider/3.jpg);"></li>
            </ul>
        </div>
        
        <!--Banner Search Form-->
        <div class="banner-search-container">
            <div class="form-outer">
                <div class="banner-search-form">
                    <h1>Find your dream home just in a click</h1>
                    <div class="text">“Local Real Estate / Marketed Internationally”</div>
                    
                    <div class="banner-form-box">
                        <div class="default-form">
                            <form method="post" action="http://effortthemes.com/html/lirive/properties-list-one.html">
                                <div class="row clearfix">
                                    <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                        <select class="custom-select-box">
                                            <option>Property Type</option>
                                            <option>Residential</option>
                                            <option>Commercial</option>
                                            <option>Agriculture</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6 col-sm-4 col-xs-12">
                                        <input type="text" name="field-name" value="" placeholder="Enter Location" required>
                                    </div>
                                    <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                        <button type="submit" class="theme-btn btn-style-one">SEARCH</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>
 <section class="property-listing">
        <div class="auto-container">
            <div class="mixitup-gallery">
                <!--Heading-->
                <div class="sec-title centered">
                    <h2>About US</h2>
                </div>
                <div id="main-wrapper">
                    <div class="row">

                         <div class="col-lg-3 col-md-6">
                                
                            <div class="panel info-box panel-white">
                                <div class="panel-body">
                                    <div class="info-box-stats">
                                        <p class="counter">{{$count = \DB::table('users')->count()}}</p>
                                        <span class="info-box-title">All User Count</span>
                                    </div>
                                    <div class="info-box-icon">
                                        <i class="icon-eye"></i>
                                    </div>
                                    <div class="info-box-progress">
                                        <div class="progress progress-xs progress-squared bs-n">
                                            <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        
                    <div class="col-lg-3 col-md-6">
                            <div class="panel info-box panel-white">
                                <div class="panel-body">
                                    <div class="info-box-stats">
                                        <p class="counter">{{$count = \DB::table('users')->where('user_type','=','1')->count()}}</p>
                                        <span class="info-box-title">Property Manager Count</span>
                                    </div>
                                    <div class="info-box-icon">
                                        <i class="icon-users"></i>
                                    </div>
                                    <div class="info-box-progress">
                                        <div class="progress progress-xs progress-squared bs-n">
                                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                           

                         <div class="col-lg-3 col-md-6">
                            <div class="panel info-box panel-white">
                                <div class="panel-body">
                                    <div class="info-box-stats">
                                        <p class="counter">{{$count = \DB::table('users')->where('user_type','=','2')->count()}}</p>
                                        <span class="info-box-title">Total Customer Count</span>
                                    </div>
                                    <div class="info-box-icon">
                                        <i class="icon-basket"></i>
                                    </div>
                                    <div class="info-box-progress">
                                        <div class="progress progress-xs progress-squared bs-n">
                                            <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                         <div class="col-lg-3 col-md-6">
                            <div class="panel info-box panel-white">
                                <div class="panel-body">
                                    <div class="info-box-stats">
                                        <p class="counter">{{$count = \DB::table('property_information')->count()}}</p>
                                        <span class="info-box-title">Total Property Count</span>
                                    </div>
                                    <div class="info-box-icon">
                                        <i class="icon-envelope"></i>
                                    </div>
                                    <div class="info-box-progress">
                                        <div class="progress progress-xs progress-squared bs-n">
                                            <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6">
                            <div class="panel info-box panel-white">
                                <div class="panel-body">
                                    <div class="info-box-stats">
                                        <p class="counter">{{$count = \DB::table('property_information')->count('city')}}</p>
                                        <span class="info-box-title">Total Property City Count</span>
                                    </div>
                                    <div class="info-box-icon">
                                        <i class="icon-envelope"></i>
                                    </div>
                                    <div class="info-box-progress">
                                        <div class="progress progress-xs progress-squared bs-n">
                                            <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>            
                      
        </div>
    </section>

    <section class="popular-places">
        <div class="auto-container">
            <!--Heading-->
            <div class="sec-title centered">
                <h2>Popular Places</h2>
            </div>
          
            <div class="popular-place-carousel owl-theme owl-carousel">
                  @foreach($propertyinform as $propertyinform)
                <!--Popular Place Box--> 
                <div class="popular-place-box">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><img src="{{url($propertyinform1->getimg($propertyinform1->id))}}" alt=""></figure>
                            <div class="overlay-content">
                                <h4>{{$propertyinform->city}}</h4>
                                <div class="count">{{$count =\DB::table('property_information')->where('city',$propertyinform->city)->count('city')}}</div>
                            </div>
                        </div>
                        
                        <a href="{{URL('search-property-city/'.$propertyinform->city)}}" name="$propertyinform->city" class="link-overlay"></a>
                    </div>
                </div>
               
                <!--Popular Place Box-->
                 @endforeach
            </div>
           
        </div>
    </section>





    <section class="team-section">
        <div class="auto-container">
            <!--Heading-->
            <div class="sec-title centered">
                <h2>Creative Agents</h2>
            </div>
            
<div class="row clearfix">
                @foreach($users as $user)
          <div class="team-member col-md-6 col-sm-6 col-xs-12">
             
                    <div class="inner-box">
                    <div class="clearfix">
                            
                    <div class="image-column col-md-5 col-sm-12 col-xs-12">
                                
                    <figure class="image"><a href=""><img src="{{$user->getUserProfile->profile_image}}" alt=""></a></figure>
                          
                            </div>
                            <!--Content Column-->
                            <div class="content-column col-md-7 col-sm-12 col-xs-12">
                                <div class="inner">
                                    <div class="title">
                                        <h2>{{$user->id}} 
                                             </h2>
                                        <h3><a href="">{{$user->firstname}} 
                                        {{$user->firstname}}</a></h3>
                                        <div class="designation">Company Agent @<a href="#">Reki Housing</a></div>
                                    </div>
                                    <div class="desc-text">Duis aute irure dolor in voccaecat reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla.</div>
                                    <div class="social-links">
                                        <ul class="clearfix">
                                            <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                            <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 @endforeach
            </div>
            
            <div class="view-all"><a href="agents.html" class="theme-btn btn-style-two">View More Agents</a></div>
            
        </div>
    </section>
    
    <!--Property Listing-->
    <section class="properties-search-section">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Posts Column-->
                <div class="posts-column col-lg-8 col-md-12 col-sm-12 col-xs-12">
                    <div class="upper-filters clearfix">
                        <!--Form Column-->
                        <div class="form-column">
                            <div class="default-form">
                                <form method="post" action="">
                                    <div class="option-box sort-by">
                                        <div class="sel-label">Sort By</div>
                                        <div class="form-group">
                                            <select class="custom-select-box">
                                                
                                               
                                            </select>
                                        </div>
                                    </div>
                                     <div class="option-box">
                                        <div class="sel-label">View</div>
                                        <div class="form-group">
                                            <select class="custom-select-box">
                                                <option>Grid</option>
                                                <option>List</option>
                                            </select>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                       
                        <!--Count Column-->
                        <div class="count-column">
                            <div><b>{{$count = \DB::table('property_information')->count()}} Property Found</div>
                        </div>
                        
                    </div>
                    
                  

                         <div class="filter-list row clearfix">

                @foreach($propertyinfor1 as $propertyinfor1)

                    <div class="default-property-box mix all for-rent col-lg-4 col-md-6 col-sm-6 col-xs-12">                   
                            <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><a href="{{URL('property-details/'.$propertyinfor1->property_slug)}}"><img src="{{url($propertyinfor1->getimg($propertyinfor1->id))}}" alt=""></a></figure>
                                <div class="property-price">${{$propertyinfor1->prices}} / Month</div>
                            </div>
                            <div class="lower-content">
                                <div class="rating-review">
                                    <div class="ratings"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></div>
                                    <div class="rev">(105 reviews)</div>
                                </div>
                                <div class="property-title">
                                    <h3><a href="{{URL('property-details/'.$propertyinfor1->property_slug)}}">{{$propertyinfor1->property_title}}</a></h3>
                                    <div class="location"><span class="fa fa-map-marker"></span>&nbsp; {{$propertyinfor1->property_location}},
                                    {{$propertyinfor1->city}}
                                    {{$propertyinfor1->state}}</div>
                                </div>
                                <div class="prop-info clearfix">
                                    <div class="prop-for"><span class="for">For {{$propertyinfor1->property_type}}</span><span class="area">{{$propertyinfor1->property_area}} sq ft.</span></div>
                                    <div class="link-box"><a href="{{URL('property-details/'.$propertyinfor1->property_slug)}}" class="theme-btn">View Details <span class="fa fa-angle-right"></span></a></div>
                                </div>
                                <div class="property-meta">
                                    <ul class="clearfix">
                                        <li><span class="icon fa fa-user"></span> {{$propertyinfor1->getName($propertyinfor1->user_id)}}</li>
                                        <li><span class="icon fa fa-calendar"></span> {{$propertyinfor1->created_at}}</li>
                                        <li class="options"><a href="#"><span class="fa fa-heart-o"></span></a> &ensp; <a href="#"><span class="fa fa-share-alt"></span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                    @endforeach
                    @foreach($propertyinfor as $propertyinfor)
                    <div class="default-property-box mix all for-sell col-lg-4 col-md-6 col-sm-6 col-xs-12">

                                          
                            <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><a href="{{URL('property-details/'.$propertyinfor->property_slug)}}"><img src="{{url($propertyinfor->getimg($propertyinfor->id))}}" alt=""></a></figure>
                                <div class="property-price">${{$propertyinfor->prices}} / Month</div>
                            </div>
                            <div class="lower-content">
                                <div class="rating-review">
                                    <div class="ratings"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></div>
                                    <div class="rev">(105 reviews)</div>
                                </div>
                                <div class="property-title">
                                    <h3><a href="{{URL('property-details/'.$propertyinfor->property_slug)}}">{{$propertyinfor->property_title}}</a></h3>
                                    <div class="location"><span class="fa fa-map-marker"></span>&nbsp; {{$propertyinfor->property_location}},
                                    {{$propertyinfor->city}}
                                    {{$propertyinfor->state}}</div>
                                </div>
                                <div class="prop-info clearfix">
                                    <div class="prop-for"><span class="for">For {{$propertyinfor->property_type}}</span><span class="area">{{$propertyinfor->property_area}} sq ft.</span></div>
                                    <div class="link-box"><a href="{{URL('property-details/'.$propertyinfor->property_slug)}}" class="theme-btn">View Details <span class="fa fa-angle-right"></span></a></div>
                                </div>
                                <div class="property-meta">
                                    <ul class="clearfix">
                                        <li><span class="icon fa fa-user"></span> {{$propertyinfor->getName($propertyinfor->user_id)}}</li>
                                        <li><span class="icon fa fa-calendar"></span> {{$propertyinfor->created_at}}</li>
                                        <li class="options"><a href="#"><span class="fa fa-heart-o"></span></a> &ensp; <a href="#"><span class="fa fa-share-alt"></span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                   
                    @endforeach
                </div>
            
                        
                    <!-- Styled Pagination -->
                                 
            </div>
<div class="search-form-column col-lg-4 col-md-12 col-sm-12 col-xs-12">
                    <div class="form-box">
                        <div class="title-header">Advance Search</div>
                        
                        <div class="default-form">
                            <form method="post" action="http://effortthemes.com/html/lirive/agents.html">
                                <div class="row clearfix">
                             
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                       
                                        <div class="field-label">Status</div>
                                        <select class="custom-select-box" id="">
                                            <option>Property Option</option>
                                            
                                            
                                        </select>
                                        
                                    </div>
                                   
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                     <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                       <div class="range-slider-one">
                                            <div class="slider-header">
                                                <div class="clearfix">
                                                    <div class="title">Area Range (sq ft):</div>
                                                    <div class="input"><input type="text" class="area-size" name="field-name" readonly></div>
                                                </div>
                                            </div>
                                             
                                            <div class="area-range-slider"></div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="range-slider-one">
                                            <div class="slider-header">
                                                <div class="clearfix">
                                                    <div class="title">Price Range ($):</div>
                                                    <div class="input"><input type="text" class="property-amount" name="field-name" readonly></div>
                                                </div>
                                            </div>
                                             
                                            <div class="price-range-slider"></div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="field-label">Location</div>
                                        <select class="custom-select-box">
                                            <option>All Cities</option>
                                            <option>Ney York</option>
                                            <option>Hong Kong</option>
                                            <option>Islamabad</option>
                                            <option>Dhaka</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <div class="field-label">Beds</div>
                                        <select class="custom-select-box">
                                            <option>All</option>
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3-5</option>
                                            <option>5-10</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                        <div class="field-label">Baths</div>
                                        <select class="custom-select-box">
                                            <option>All</option>
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3-5</option>
                                            <option>5-10</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="separator"></div>
                                    </div>
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <div class="field-label">Additional Features</div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-1">
                                            <label for="cbox-1">Swimming Pool</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-2">
                                            <label for="cbox-2">Air Conditioning</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-3">
                                            <label for="cbox-3">Laundry Room</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-4">
                                            <label for="cbox-4">Gym</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-5">
                                            <label for="cbox-5">Central Heating</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-6">
                                            <label for="cbox-6">Fire Safty</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-7">
                                            <label for="cbox-7">Window Cinvering</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-8">
                                            <label for="cbox-8">Alarm</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-9">
                                            <label for="cbox-9">Garden</label>
                                        </div>
                                        <div class="check-box">
                                            <input type="checkbox" id="cbox-10">
                                            <label for="cbox-10">Guest House</label>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                        <button type="submit" class="theme-btn btn-style-one">Search Filters</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    
                    </div>
                </div>
            </div>
    </div>
    </section>
  












    
    @stop