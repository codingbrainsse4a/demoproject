@extends('layout.applayout')
@section('content')

    <section class="inner-page-banner style-two" style="background-image:url(assets/images/background/bg-page-title.jpg);">
        <div class="auto-container">
            <h1>Registration</h1>
            <div class="text">Duis aute irure dolor in reprehenderit</div>
        </div>
    </section>

     <section class="register-section">
     <div class="auto-container">
     <div class="row clearfix">
     	@if(Session::has('success'))
                        <div class="alert alert-success">
                            {{ Session::get('success') }}
                            <br>
                           <h3> Please Click Here For</h3><a href="{{URl('login')}}">Login</a></h3>

                        </div>
                                    @endif

                                @if (Session::has('error'))
                                 <div class="alert alert-danger">
                                {{Session::get('error')}}
                            </div>
                                @endif
                               

     <div class="form-column column col-lg-6 col-md-6 col-sm-12 col-xs-12">
                
                <div class="sec-title medium">
                <h2>Create an account</h2>
                </div>
    <div class="styled-form register-form">
                    <form method="post" action="{{URL('register')}}"> 
                    {{csrf_field()}} 
    <div class="form-group">
    	<label for="user_type">User Type:</label>
                        <select class="custom-select-box" name="user_type">
                        <option >Select User Type</option>
                        <option value="2" {{ old('user_type')=='2' ? 'selected="selected"' : '' }}>Customer</option>
                        <option value="1" {{ old('user_type')=='1' ? 'selected="selected"' : '' }}>Property manager</option>
                        </select>
                        <span style="color: red">
                              {{$errors->first('user_type')}}</span>

    </div> 
    <div class="form-group">
    	<label for="firstname">First Name:</label>
                <input class="form-control" type="text" name="firstname" value="{{ old('firstname') }}" placeholder="Please Enter Your firstname" >
                <span style="color: red">
                              {{$errors->first('firstname')}}</span>
    </div>    
    <div class="form-group">
    	 <label for="lastname">Last Name:</label>        
                <input class="form-control" type="text" name="lastname" value="{{ old('lastname') }}" placeholder="Please Enter Your lastname" >
                <span style="color: red">
                              {{$errors->first('lastname')}}</span>
    </div>  
    <div class="form-group">
    	<label for="contactno">Contact No.:</label> 
                <input class="form-control" type="text" name="contactno" value="{{ old('contactno') }}" placeholder="Please Enter contactno" >
                <span style="color: red">
                              {{$errors->first('contactno')}}</span>
    </div>
    <div class="form-group">
    	<label for="email">Email:</label>
                <input class="form-control" type="email" name="email" value="{{ old('email') }}" placeholder="Please Enter Email Address" >
                <span style="color: red">
                              {{$errors->first('email')}}</span>
    </div>
    <div class="form-group">
    	<label for="password">Password:</label>
               <input class="form-control" type="password" name="password" value="{{ old('password') }}" placeholder="Please Enter Password" >
               <span style="color: red">
                              {{$errors->first('password')}}</span>
    </div>
    <div class="form-group">
    	<label for="confirm_password">Confirm Password:</label>
               <input class="form-control" type="password" name="confirm_password" value="{{ old('confirm_password') }}" placeholder="Please Re Enter Password" >
               <span style="color: red">
                              {{$errors->first('confirm_password')}}</span>
    </div> 

    {{csrf_field()}}  
    <div class="clearfix">
               <div class="form-group pull-left">
               <button type="submit" class="theme-btn btn-style-one">Register</button>
               </div>
    </div>     
    </form>
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div>
                    </section>
                
                @stop
