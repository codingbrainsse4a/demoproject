     @extends('layout.applayout')
    @section('content')
    
    
    <!--Inner Page Banner-->
    <section class="inner-page-banner style-two" style="background-image:url(assets/images/background/bg-page-title.jpg);">
        <div class="auto-container">
            <h1>Login</h1>
            <div class="text">Duis aute irure dolor in reprehenderit</div>
        </div>
    </section>
    
    
    <!--Register Section-->
    <section class="register-section">
        <div class="auto-container">
            <div class="row clearfix">
                
              @if(Session::has('success'))
                <div class="alert alert-success">
                    {{ Session::get('success') }}
                </div>


                            @endif

                                @if (Session::has('error'))
                                 <div class="alert alert-danger">
                                {{Session::get('error')}}
                            </div>
                                @endif
  
                <!--Form Column-->
                <div class="form-column column col-lg-5 col-md-6 col-sm-12 col-xs-12">
                
                    <div class="sec-title medium">
                        <h2>Login</h2>
                    </div>
                    
                    <!--Login Form-->
                    <div class="styled-form login-form">
                        <form method="post" action="{{URL('loginme')}}">
                              {{ csrf_field() }}

                             
                             
                            <div class="form-group">
                                <input type="email" name="email" value="" placeholder="Email Address">
                            </div>
                            <div class="form-group">
                                <input type="password" name="password" value="" placeholder="Password">
                            </div>
                            <div class="clearfix">
                                <div class="form-group pull-left">
                                    <button type="submit" class="theme-btn btn-style-one">login</button>
                                </div>
                                <div class="form-group pull-right">
                                    <a href="{{URL('register')}}" class="theme-btn btn-style-one">Register For New User</a>                                
                                </div>
                                <br>
                                <!-- <div class="form-group social-links-two padd-top-5 pull-right">
                                    Or login with <a href="#" class="img-circle facebook"><span class="fa fa-facebook-f"></span></a> <a href="#" class="img-circle twitter"><span class="fa fa-twitter"></span></a> <a href="#" class="img-circle google-plus"><span class="fa fa-google-plus"></span></a>
                                </div> -->
                                 
                            </div>
                           
                          
                            
                        </form>
                    </div>
                    
                </div>
                
        <div class="form-column column col-lg-6 col-md-6 col-sm-12 col-xs-12">  
        <div class="carousel-outer">
        <div class="testimonial-carousel-one single-item-carousel owl-theme owl-carousel">
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                                <!--Image Column-->
                                <div class="form-column column col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="slide-inner">
                            
                                <!--Image Column-->
                                <div class="form-column column col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                            </div>
                        </div>
                               
                   
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                                
                                <div class="form-column column col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                                </div>
                        </div>
                    </div>
                    
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                                <!--Image Column-->
                                <div class="form-column column col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="slide-item">
                        <div class="slide-inner">
                            <div class="clearfix">
                             
                                <div class="form-column column col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <figure class="image"><img src="assets/images/resource/featured-image-10.jpg" alt=""></figure>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    
                </div>
            </div>
            



            </div>


           </div>
               
            </div>
       </section>
    </section>
    
    @stop