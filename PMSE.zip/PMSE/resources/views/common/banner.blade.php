<section class="home-banner with-border">
    	<!--Banner Slider-->
        <div class="banner-slider-container">
        	<ul class="banner-slider owl-theme owl-carousel">
            	<li class="slide-item" style="background-image:url(images/main-slider/1.jpg);"></li>
                <li class="slide-item" style="background-image:url(images/main-slider/2.jpg);"></li>
                <li class="slide-item" style="background-image:url(images/main-slider/3.jpg);"></li>
            </ul>
        </div>
        
        <!--Banner Search Form-->
        <div class="banner-search-container">
        	<div class="form-outer">
            	<div class="banner-search-form">
                	<h1>Find your dream home just in a click</h1>
                    <div class="text">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur sint.</div>
                    
                    <div class="banner-form-box">
                        <div class="default-form">
                            <form method="post" action="http://effortthemes.com/html/lirive/properties-list-one.html">
                                <div class="row clearfix">
                                    <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                        <select class="custom-select-box">
                                            <option>Property Type</option>
                                            <option>Residential</option>
                                            <option>Commercial</option>
                                            <option>Agriculture</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6 col-sm-4 col-xs-12">
                                        <input type="text" name="field-name" value="" placeholder="Enter Location" required>
                                    </div>
                                    <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                        <button type="submit" class="theme-btn btn-style-one">SEARCH</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </section>