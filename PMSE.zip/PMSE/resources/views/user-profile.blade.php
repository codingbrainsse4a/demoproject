   @extends('layout.applayout')
    @section('content')

<section class="inner-page-banner style-two" style="background-image:url(assets/images/background/bg-page-title.jpg);">
        <div class="auto-container">
            <h1>Agent Profile</h1>
            <div class="text">Reprehenderit in voluptate velit esse cillum dolore.</div>
        </div>
    </section>
    
    
    <!--Agent Details-->
    <section class="agent-details">
        <div class="auto-container">
            @if(Session::has('success'))
                <div class="alert alert-success">
                    {{ Session::get('success') }}
                </div>


                            @endif

                                @if (Session::has('error'))
                                 <div class="alert alert-danger">
                                {{Session::get('error')}}
                            </div>
                                @endif
        <div class="row clearfix">
             <form method="post" action="my-profile-updated" enctype="multipart/form-data">
                         {{ csrf_field() }}
        <div class="image-column col-md-4 col-sm-6 col-xs-12">
        <figure class="image">
           @if(isset($profileimage))
          @if($profileimage->profile_image!='')
            <img src="{{$profileimage->profile_image}}" alt="">
             @endif 
            @else
            <img src="{{URL('assets/images/yourphoto.jpg')}}" alt="">
            @endif 
        <br>
        <label class="control-label">Change Image :</label>
         <div>
        <input type="file" name="browse" accept="image/*"/>              
                </div>

                <br>
<br>
         <label class="control-label">Please Submit Your Id Proof :</label>
         <div>
        <input type="file" name="idProof" accept="image/*"/>
        <figure class="image">
           @if(isset($profileimage))
          @if($profileimage->id_proof!='')
            <img src="{{$profileimage->id_proof}}" alt="">
             @endif
         @else
         <br>
            <img src="{{URL('assets/images/idproofsample.png')}}" alt="">
            @endif 
        </figure>               
                                
                </div>
            </div>
                
                <!--Content Column-->
                <div class="content-column col-md-8 col-sm-12 col-xs-12">
                    <div class="inner">
                        <div class="details-header clearfix">
                            <div class="row">
                                <div class=" col-md-12 ">
                                    <div class="title">
                                        <h3>Profile Information</h3>
                                        <!-- <div class="designation">Agent in Los Angeles</div> -->
                                    </div>
                                </div>
                            </div>
                           
                                <div class="row">
                                    <div class=" col-md-6 ">
                                        <div class="form-group">
                                            <label class="control-label">First Name:</label>
                                                    <input type="text" class="form-control" name="firstname" placeholder="First Name" value="{{Auth::user()->firstname}}">
                                                        @if ($errors->has('firstname'))
                                                    <span class="help-block">
                                                    <strong>{{ $errors->first('firstname') }}</strong>
                                                    </span>
                                                        @endif
                                                
                                         </div>
                                    </div>
                            </div>
                          <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">Last Name:</label>
                                                <input type="text" class="form-control" name="lastname" placeholder="last name" value="{{Auth::user()->lastname}}">
                                                    @if ($errors->has('lastname'))
                                                <span class="help-block">
                                                <strong>{{ $errors->first('lastname') }}</strong>
                                                </span>
                                                    @endif
                                           
                                     </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">Contact No:</label>
                                                <input type="text" class="form-control" name="contactno" placeholder="contactno" value="{{Auth::user()->contactno}}">
                                                    @if ($errors->has('contactno'))
                                                <span class="help-block">
                                                <strong>{{ $errors->first('contactno') }}</strong>
                                                </span>
                                                    @endif
                                             </div>
                                     </div>
                                </div>
                     

                            <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">Email:</label>
                                                <input type="text" class="form-control" name="email" placeholder="email" value="{{Auth::user()->email}}">
                                                    @if ($errors->has('email'))
                                                <span class="help-block">
                                                <strong>{{ $errors->first('email') }}</strong>
                                                </span>
                                                    @endif
                                             </div>
                                     </div>
                                </div>
                        
                            <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">Adress1:</label>
                                <input type="text" class="form-control" name="address1" placeholder="address1" value={{old('address1')!= "" ? old('address1') : Auth::user()->address1}}>
                                            </div>
                                     </div>
                                </div>
                         
                            <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">Adress2:</label>
                                                <input type="text" class="form-control" name="address2" placeholder="address1" value="">
                                            </div>
                                     </div>
                                </div>
                          
                            <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">City:</label>
                                                <input type="text" class="form-control" name="city" placeholder="city" value="">
                                            </div>
                                     </div>
                                </div>
                 
                            <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">State:</label>
                                                <input type="text" class="form-control" name="state" placeholder="state" value="">
                                            </div>
                                     </div>
                                </div>
                                <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">PinCode:</label>
                                                <input type="text" class="form-control" name="pincode" placeholder="pincode" value="">
                                            </div>
                                     </div>
                                </div>
                                <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">Country:</label>
                                                <input type="text" class="form-control" name="country" placeholder="country" value="">
                                            </div>
                                     </div>
                                </div>
                                 {{ csrf_field() }}
                           <div class="clearfix">
                                <div class="form-group pull-left">
                                    <button type="submit" class="theme-btn btn-style-one">Update</button>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                </form>
            </div>
            
        </div>
    </section>
    
    
    
    
    <!--NewsLetter Section-->
    <section class="newsletter-section with-negative-margin">
        <div class="auto-container">
            <div class="outer-box">
                <!--Heading-->
                <div class="sec-title centered">
                    <h2>Get Update</h2>
                </div>
                
                <!--Newsletter Style One-->
                <div class="newsletter-style-one">
                    <div class="desc-text">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia est deserunt mollit anim laborum. Sed perspiciatis unde omnis iste natus.</div>
                    
                    <form method="post" action="http://effortthemes.com/html/lirive/contact.html">
                        <div class="form-group">
                            <input type="email" name="text" value="" placeholder="Enter Your Email" required>
                            <button type="submit" class="theme-btn">Subscribe</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    
  

    @stop