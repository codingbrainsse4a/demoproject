
$(document).ready(function(){
    $('#add_more').click(function()  {
    var current_count = $('input[type="file"]').length;
    var count = current_count;
    if (count<=9) {
     $('#file_upload').prepend('<p><input type="file" name="mediaimage" /></p>');
 }
});

});


