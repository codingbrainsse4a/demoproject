<?php
use Illuminate\Support\Facades\Input;
use App\PropertyInformation;
use App\User;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
	  $property_information['propertyinfor']= \App\PropertyInformation::where('property_type','=','sale')->with('getImage','getUser','getUserProfile')->get();
	  $property_information['propertyinfor1']= \App\PropertyInformation::where('property_type','=','rent')->with('getImage','getUser','getUserProfile')->get();

	  $timestemp1 = PropertyInformation::find(1);
	  $timestemp1->created_at->toFormattedDateString();
      $timestemp=$timestemp1->created_at;
      $now = now();
      
     $property_information['diff'] = ($timestemp->diff($now)->days < 1)
    ? 'today'
    : $timestemp->diffInDays($now);
    //dd($timestemp);
    //dd($now);
    //dd($property_information);



	  $property_information['propertyinform'] = \App\PropertyInformation::distinct('city')->get('city');

      $property_information['propertyinform1'] = \App\PropertyInformation::first();
         //dd($property_information);

	  $property_information['user'] = User::where('user_type','=','1')->with('getUserProfile')->get();

		if(Auth::check()){
			$property_information['profileimage']= App\UsersProfile::where('user_id',Auth::user()->id)->first();
		
	    	return view('welcome',$property_information);
		 }else{
				//print_r($property_information);
			return view('welcome',$property_information);
		 }
	
    });
    Route::get('Home-Page', function () {
	$property_information['propertyinfor']= \App\PropertyInformation::where('property_type','=','sale')->with('getImage','getUser','getUserProfile')->get();
	  $property_information['propertyinfor1']= \App\PropertyInformation::where('property_type','=','rent')->with('getImage','getUser','getUserProfile')->get();

	  $timestemp1 = PropertyInformation::find(1);
	  $timestemp1->created_at->toFormattedDateString();
      $timestemp=$timestemp1->created_at;

  $A['year'] = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $timestemp)->year;
  $A['month'] = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $timestemp)->month;
  $A['day'] = Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $timestemp)->day;
//dd($A);



	  $property_information['propertyinform'] = \App\PropertyInformation::distinct('city')->get('city');

      $property_information['propertyinform1'] = \App\PropertyInformation::first();
         //dd($property_information);

	  $property_information['user'] = User::where('user_type','=','1')->with('getUserProfile')->get();

		if(Auth::check()){
			$property_information['profileimage']= App\UsersProfile::where('user_id',Auth::user()->id)->first();
		
	    	return view('welcome1',$property_information);
		 }else{
				//print_r($property_information);
			return view('welcome1',$property_information);
		 }
	
    });

Route::get('Old-Home-Page', 'UserController@old');
//Route::get('searchin', 'PropertyController@search');
//Route::get('/search', 'PropertyController@search');
// {
//   $q = Input::get('q');
//   if($q !=""){
// $searchinfor = PropertyInformation::where('property_title','LIKE','%'.$q.'%')
//   	                                 ->orWhere('city', 'LIKE','%'.$q.'%')
//   	                                 ->get();
//   	                                  dd($searchinfor);
//   if(count($searchinfor) > 0)
//   return view('search')->withDetails($searchinfor)->withQuery($q);
//    } 
//   return view('search')->withMessage("Not Found");
// });

Route::get('login', 'UserController@index');
Route::post('loginme','UserController@loginme')->name('/login');
Route::get('/logout', 'UserController@get_logout');
Route::get('register','UserController@create');
Route::post('register','UserController@store');
Route::get('my-profile', 'UserController@userProfile');
Route::post('my-profile-updated', 'UserController@updateProfile');
Route::get('my-profile-updated', 'UserController@updated');

Route::get('aboutus', 'FrontendController@aboutUs');
Route::get('contactus', 'FrontendController@contactUs');
Route::post('send_information', 'FrontendController@storecontact');
Route::get('sendinformation', 'FrontendController@donecontactus');

Route::get('add-property', 'PropertyController@addProperty');
Route::post('property_added','PropertyController@store_addproperty');
Route::get('property_added', 'PropertyController@propertyadded');
Route::get('my-property-list', 'PropertyController@myProperty');
Route::get('property-details/{property_slug}','PropertyController@propertyDetails');
Route::get('search-property', 'PropertyController@search_property');
Route::get('search-property-city-{city}', 'PropertyController@propertyCityWise');

Route::get('blog','BlogController@blog');
Route::get('add-blog','BlogController@create_blog');
Route::post('blog-added','BlogController@store_blog');
Route::get('blogadded','BlogController@blogadded');
// For Test 
Route::get('/dynamic_dependent', 'DynamicDependentController@index');
Route::post('dynamic_dependent/fetch', 'DynamicDependentController@fetch')->name('dynamicdependent.fetch');







