<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Blog;
use Auth;

   class BlogController extends Controller
   {
   Public function create_blog(){
    if(\Auth::check()){
      $profileimg= \App\UsersProfile::where('user_id',\Auth::user()->id)->first();
      return view('new-blog',['profileimage'=>$profileimg]);
    }else{
      return view('new-blog');
  
   }
}

   public function store_blog(Request $request) 
            {
              $validator=Validator::make($request->all(),[
              'blog_type'          =>'required',
              'blog_title'         =>'required',
              'blog_description'   =>'required',
              
            ]
        );

    if($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInput();
      }else{
         $blog = new Blog();          
      $blog->blog_type   = $request->blog_type;
      $blog->blog_title  = $request->blog_title;
      $blog->blog_description = $request->blog_description;
          if($request->file('blogimage') !="" )
          {
             $image = $request->file('blogimage');
             $filename = time().$image->getClientOriginalExtension();
             $destinationPath = public_path('/blog_image');
             $image->move($destinationPath, $filename); 
             $blog->blog_image = '/blog_image/'.$filename;
           }
           //dd($blog);
           $blog->user_id=Auth::User()->id;
           $blog->save();
          
          return redirect()->back()->with('success','Blog added successfully ');
         }
         }


public function blogadded()
            {
          return view('addblog');
            }

   Public function blog(){
   	if(\Auth::check()){
      $profileimg= \App\UsersProfile::where('user_id',\Auth::user()->id)->first();
      return view('blog',['profileimage'=>$profileimg]);
    }else{
      return view('blog');
   }
}
}
