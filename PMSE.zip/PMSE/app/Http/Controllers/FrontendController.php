<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\ContactUs;
use App\User;
use App\PropertyInformation;
use DB;
use App\Quotation;



class FrontendController extends Controller
{
public function aboutUs(Request $request)
    {
      $property_information['users'] = \App\User::where('user_type','=','1')->with('getUserProfile')->get();
     // $property_information['propertyinfo']= PropertyInformation::where('prices','<=','15000')->get();
      $property_information['propertyinfor']= \App\PropertyInformation::where('property_type','=','sale')->with('getImage','getUser','getUserProfile')->get();
    $property_information['propertyinfor1']= \App\PropertyInformation::where('property_type','=','rent')->with('getImage','getUser','getUserProfile')->get();
      $property_information['propertyinform'] = \App\PropertyInformation::distinct('city')->get('city');
      $property_information['propertyinform1'] = \App\PropertyInformation::first();
      $property_information['propertyinform2'] = \App\PropertyInformation::distinct('property_type')->get('property_type');
      //dd($property_information);
      if(\Auth::check()){
      $property_information['profileimage']= \App\UsersProfile::where('user_id',\Auth::user()->id)->first();
      return view('aboutus',$property_information);
    }else{
      return view('aboutus',$property_information);
}
}
   public function contactUs()
    {
    	if(\Auth::check()){
    	$profileimg= \App\UsersProfile::where('user_id',\Auth::user()->id)->first();
      return view('contactus',['profileimage'=>$profileimg]);
    }else{
			return view('contactus');
}
}
   public function storecontact(Request $request)
   {
   	$validator=Validator::make($request->all(),[
              'name'       =>'required',
              'email_id'   =>'required|email|unique:contact_us',
              'contact_no' =>'min:10|max:10',
              'message'    =>'required',
              'subject'    => 'required',
   	]
   );
   	if($validator->fails()){
        return redirect()->back()->withErrors($validator)->withInput();
   }else{
   	   $contactus = new ContactUs();
   	   $contactus->name = $request->name;
       $contactus->subject = $request->subject;
       $contactus->message = $request->message;
       $contactus->contact_no = $request->contact_no;
       $contactus->email_id = $request->email_id;
       $contactus->save();
                   
  return redirect()->back()->with('success','Thank you!'.' '.$request->name.' '.'Your message has been successfully sent. We will contact you very soon!');
   }
}
      public function donecontactus()
          {
        return view('contactus');
          }

}
