<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\User;
use App\UserAccess;
use App\UsersProfile;
use Auth;
use Hash;
use Redirect;



class UserController extends Controller
{
    public function index()
    {
      return view('login');
    }
    
    public function create()
    {
        return view('register');
    }

    public function store(Request $request)
    {
        $validator=Validator::make($request->all(),[
        'user_type' =>'required',
        'firstname' =>'required',
        'lastname'  =>'required',
        'contactno' =>'min:10|max:12',
        'email'     =>'required|email|unique:users',
        'password'  =>'required',
        'confirm_password' =>'required|same:password',
        ]
    );
         if($validator->fails()){
          return redirect()->back()->withErrors($validator)->withInput();
        }else{
            $user = new User();
            $user_access = new UserAccess();
            $user->user_type = $request->user_type;
            $user->firstname = $request->firstname;
            $user->lastname  = $request->lastname;
            $user->contactno = $request->contactno;
            $user->email     = $request->email;
            $user->password  = Hash::make($request->password);
            $user->confirm_password = Hash::make($request->confirm_password);
            $user->save();
            
            return redirect('register')->with('success','You are register Successfully !');

        }


    }


    public function loginme(Request $request) {     


                $attempt = Auth::attempt( array('email' => $request->email, 'password' => $request->password) );
                  
                if($attempt) {
                    return Redirect::to('/');
                } else {
                    return Redirect::to('login')->with('error','  Please enter valid email or password');
                }
            }

        public function userProfile()
          {
              $profileimg= UsersProfile::where('user_id',Auth::user()->id)->first();
               
             
                return view('user-profile',['profileimage'=>$profileimg]);
          }

          public function updateProfile(Request $request)
          {
            $user_id=Auth::user()->id;
            $user =User::find($user_id);
            $user ->firstname = $request->firstname;
            $user ->lastname = $request->lastname;
            $user ->contactno = $request->contactno;
            $user->save();

            $is_profile_created= UsersProfile::where('user_id', $user_id)->first();
            if ( $is_profile_created !=null){

                $userprofile = UsersProfile::find($is_profile_created->id);
            }else{
                $userprofile = new UsersProfile();
            }
            $userprofile ->user_id =$user_id;
            $userprofile ->address1 =$request->address1;
            $userprofile ->address2 =$request->address2;
            $userprofile ->country =$request->country;
            $userprofile ->state =$request->state;
            $userprofile ->city =$request->city;
            $userprofile ->pincode =$request->pincode;
            if($request->file('browse')!="")
            {
                $image = $request ->file('browse');
                $filename = time().rand(10,100).'.'.$image->getClientOriginalExtension();
             $destinationPath = public_path('/profile_image');
             $image->move($destinationPath, $filename); 
             $userprofile->profile_image = '/profile_image/'.$filename;
            }
            if($request->file('idProof') !="" ){
           $image = $request->file('idProof');
           $filename = $user->id.'_'.time().'.'.$image->getClientOriginalExtension();
           $destinationPath = public_path('/id_proof');
           $image->move($destinationPath, $filename);
           $userprofile->id_proof = '/id_proof/'.$filename;
            }
             $userprofile->save();
             return redirect()->back()->with('success','Profile updated successfully ');

            }
             public function updated()
              {
                   
              return view('user-profile');
              
              }
   
    public function edit($id)
    {
        //
    }
    public function update(Request $request, $id)
    {
        //
    }
    public function destroy($id)
    {
        //
    }


    public function get_logout(Request $request){
                Auth::logout();
                return redirect('login');
            }
}
