<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use App\PropertyInformation;
use App\PropertyMedia;
use App\UsersProfile;
use Auth;
use Redirect;
use DB;



class PropertyController extends Controller
{
      public function addProperty(){
        if (\Auth::check()) {
        $profileimg = \App\UsersProfile::where('user_id', \Auth::user()->id)->first();
        return view('add-property',['profileimage' => $profileimg]);
            } else {
        return view('add-property');
      }
        }

      public function store_addproperty(Request $request)
                  {
            $validator = Validator::make($request->all(),[
            'property_title'  =>'required|unique:property_information',
            'property_type'           =>'required',
            'prices'                  =>'required|numeric',
            'property_area'           =>'required|numeric',
            'property_floor'          =>'required|numeric',
            'property_description'    =>'required',
            'property_location'       =>'required',
            'area'                    =>'required',
            'city'                    =>'required',
            'state'                   =>'required',
            'pincode'                 =>'required|min:5|max:7',
            'country'                 =>'required',
            'media_type'              =>'required',             
              ]
              );
        if($validator->fails()){
        return redirect()->back()->withErrors($validator)->withInput();
                  }else{

                  $property = new PropertyInformation();
                  $property->property_title = $request->property_title;
                  $property->property_type = $request->property_type;
                  $property->prices = $request->prices;
                  $property->property_area = $request->property_area;
                  $property->property_floor = $request->property_floor;
                $property->property_description = $request->property_description;
                  $property->property_location = $request->property_location;
                  $property->area = $request->area;
                  $property->city = $request->city;
                  $property->state = $request->state;
                  $property->pincode = $request->pincode;
                  $property->country = $request->country;
                  $property->property_slug = str_replace(' ', '-',$request->property_title);

                                
                  $property->user_id=Auth::user()->id;         
                  $property->save();
                  $property->id;      
                  if( $request->file('mediaimage') != ""){
                                

                  foreach($request->file('mediaimage') as $key=>$file){
               // $mediaimg=$mediaimg.$key;
                  $mediaimg = new PropertyMedia();   
                  $filename=time().rand(10,100).'.'.$file->getClientOriginalExtension();
                  $destinationPath = public_path('/media_path');
                  $file->move($destinationPath, $filename);      
                  $mediaimg->media_path =  '/media_path/'.$filename;
                  $mediaimg->property_id= $property->id;
                //$mediaimg->user_id= $user->id;
                  $mediaimg->media_type = $request->media_type;
                  $mediaimg->save(); 

                    }
                      }
                          }  
                return redirect::to('/property_added')->with('success','Property added successfully ');
                     }
            public function propertyadded()
          	{
            $profileimg = \App\UsersProfile::where('user_id', \Auth::user()->id)->first();
            return view('add-property',['profileimage' => $profileimg]);
             }
  
            public function myProperty() {
            $property_information['propertyinfo']= \App\PropertyInformation::where('user_id',Auth::user()->id)->get();
            $property_information['profileimage'] = \App\UsersProfile::where('user_id', \Auth::user()->id)->first();
            return view('my-property', $property_information);
            }

            // $propertyinfo= PropertyInformation::where('user_id',Auth::user()->id)->get();
            // return view('my-property',['property_information'=>$propertyinfo]);
          
          public function propertyDetails(Request $request)
            {
    /*$user['result']=DB::table('users')
            ->leftJoin('property_information', 'users.id', '=', 'property_information.user_id')
            ->select('users.*', 'property_information.*')
            ->get();
    // foreach ($result as $key => $value) {
   //  echo $value->property_title;
    $user['property_information']= PropertyInformation::where(['user_id'=>Auth::user()->id,'property_slug'=>$request->property_slug])->get();
    $user['profileimage']= UsersProfile::where('user_id',Auth::user()->id)->first();*/
    //$profileimage = \App\UsersProfile::where('user_id',Auth::user()->id)->first();
             $user = PropertyInformation::with('getImage','getUser','getUserProfile')->where('property_slug',$request->property_slug)->first();
            return view('property-details',['user'=>$user]);
            }

    // public function propertyDetails(Request $request)
    //   {

    //     $propertyinfo= PropertyInformation::where(['user_id'=>Auth::user()->id,'property_slug'=>$request->property_slug])->get();
    //   return view('property-details',['property_information'=>$propertyinfo]);
    //   }
      public function search_property(){
          $q = Input::get('q');
          if($q !=""){
      $property_information['propertyinfo'] = PropertyInformation::where('property_title','LIKE','%'.$q.'%')
      ->orWhere('city', 'LIKE','%'.$q.'%')
      ->orWhere('property_location', 'LIKE','%'.$q.'%')
      ->orWhere('city', 'LIKE','%'.$q.'%')
      ->get();
        }else{
      $property_information['propertyinfo']= PropertyInformation::get();}
        if (\Auth::check()) {
      $property_information['profileimage']= UsersProfile::where('user_id',Auth::user()->id)->first();
      return view('search-property',$property_information);
           } else {
      return view('search-property',$property_information);
           }
              }

      public function propertyCityWise($city,Request $request){
        $q = Input::get($city);
        //dd($city);
        $property_information['propertyinfo']= PropertyInformation::where('city',$city)->get();
        if (\Auth::check()) {
      $property_information['profileimage']= UsersProfile::where('user_id',Auth::user()->id)->first();
      return view('search-property-city',$property_information);
           } else {
      return view('search-property-city',$property_information);
           }
      
            }
          }

    //    public function search(Request $request)
    //  {
    //   $q = Input::get('q');
    //   if($q !=""){
    //   $property_information['propertyinfo'] = PropertyInformation::where('property_title','LIKE','%'.$q.'%')
    //    ->orWhere('city', 'LIKE','%'.$q.'%')
    //    ->get();
    //       //dd($searchinfor);
    //       }else{
    //   $property_information['propertyinfo']= PropertyInformation::get();}
    //   if (\Auth::check()) {
    //   $property_information['profileimage']= UsersProfile::where('user_id',Auth::user()->id)->first();
    //   return view('search',$property_information);
    //   } else {
    //   return view('search',$property_information);
    //   }
    // }
    //}
   
