<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserAccess extends Model
{
   public $table='users';
}
