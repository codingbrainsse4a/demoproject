<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\PropertyMedia;


class PropertyInformation extends Model
{
	public function getimg($id){


	 	$img = PropertyMedia::where('property_id',$id)->first();
	 	if($img==null)
	 		return '';
	 	else
	 		return $img->media_path;
	}


	public function getName($id){
		$user=User::where('id',$id)->first();
		return $user->firstname.' '.$user->lastname;
	}

	public function getImage(){
		return $this->hasMany('App\PropertyMedia','property_id','id');
	}

	public function getUser(){
		return $this->hasOne('App\User','id','user_id');
	}

	public function getUserProfile(){
		return $this->hasOne('App\UsersProfile','user_id','user_id');
	}
}
