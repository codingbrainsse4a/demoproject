<?php 



function getuserprofile($user_id){

    $user=App\UserProfile::where('user_id',$user_id)->first();

    return $user->city.' '.$user->state;

}
?>