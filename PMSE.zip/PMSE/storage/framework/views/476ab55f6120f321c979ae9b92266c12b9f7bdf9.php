<?php /* C:\xampp\htdocs\PMSE\resources\views/aboutus.blade.php */ ?>
    
    <?php $__env->startSection('content'); ?>

     <section class="home-banner with-border">
<div class="banner-slider-container">
            <ul class="banner-slider owl-theme owl-carousel">
            <li class="slide-item" style="background-image:url(assets/images/main-slider/1.jpg);"></li>
            <li class="slide-item" style="background-image:url(assets/images/main-slider/2.jpg);"></li>
            <li class="slide-item" style="background-image:url(assets/images/main-slider/3.jpg);"></li>
            </ul>
        </div>
        
        <!--Banner Search Form-->
        <div class="banner-search-container">
            <div class="form-outer">
                <div class="banner-search-form">
                    <h1>Find your dream home just in a click</h1>
                    <div class="text">“Local Real Estate / Marketed Internationally”</div>
                    
                    <div class="banner-form-box">
                        <div class="default-form">
                            <form method="post" action="http://effortthemes.com/html/lirive/properties-list-one.html">
                                <div class="row clearfix">
                                    <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                        <select class="custom-select-box">
                                            <option>Property Type</option>
                                            <option>Residential</option>
                                            <option>Commercial</option>
                                            <option>Agriculture</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6 col-sm-4 col-xs-12">
                                        <input type="text" name="field-name" value="" placeholder="Enter Location" required>
                                    </div>
                                    <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                        <button type="submit" class="theme-btn btn-style-one">SEARCH</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>
 

    <!--Property Listing-->
    <section class="properties-search-section">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Posts Column-->
                <div class="posts-column col-lg-8 col-md-12 col-sm-12 col-xs-12">
                    <div class="upper-filters clearfix">
                        <!--Form Column-->
                        <div class="form-column">
                            <div class="default-form">
                                <form method="post" action="">
                                    <div class="option-box sort-by">
                                        <div class="sel-label">Sort By</div>
                                        <div class="form-group">
                <select name="propertytype" id="propertytype" class="custom-select-box abc">
                            <option value="">Select Property Type</option>
                            <?php $__currentLoopData = $propertyinform2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search_property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="">For <?php echo e($search_property->property_type); ?></option>
                      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                     
                                </form>
                            </div>
                        </div>
              
                    </div>
                   
                         <div class="filter-list row clearfix">

                <?php $__currentLoopData = $propertyinfor1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propertyinfor1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="default-property-box mix all for-rent col-lg-4 col-md-6 col-sm-6 col-xs-12">                   
                            <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><a href="<?php echo e(URL('property-details/'.$propertyinfor1->property_slug)); ?>"><img src="<?php echo e(url($propertyinfor1->getimg($propertyinfor1->id))); ?>" alt=""></a></figure>
                                <div class="property-price">$<?php echo e($propertyinfor1->prices); ?> / Month</div>
                            </div>
                            <div class="lower-content">
                                <div class="rating-review">
                                    <div class="ratings"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></div>
                                    <div class="rev">(105 reviews)</div>
                                </div>
                                <div class="property-title">
                                    <h3><a href="<?php echo e(URL('property-details/'.$propertyinfor1->property_slug)); ?>"><?php echo e($propertyinfor1->property_title); ?></a></h3>
                                    <div class="location"><span class="fa fa-map-marker"></span>&nbsp; <?php echo e($propertyinfor1->property_location); ?>,
                                    <?php echo e($propertyinfor1->city); ?>

                                    <?php echo e($propertyinfor1->state); ?></div>
                                </div>
                                <div class="prop-info clearfix">
                                    <div class="prop-for"><span class="for">For <?php echo e($propertyinfor1->property_type); ?></span><span class="area"><?php echo e($propertyinfor1->property_area); ?> sq ft.</span></div>
                                    <div class="link-box"><a href="<?php echo e(URL('property-details/'.$propertyinfor1->property_slug)); ?>" class="theme-btn">View Details <span class="fa fa-angle-right"></span></a></div>
                                </div>
                                <div class="property-meta">
                                    <ul class="clearfix">
                                        <li><span class="icon fa fa-user"></span> <?php echo e($propertyinfor1->getName($propertyinfor1->user_id)); ?></li>
                                        <li><span class="icon fa fa-calendar"></span> <?php echo e($propertyinfor1->created_at); ?></li>
                                        <li class="options"><a href="#"><span class="fa fa-heart-o"></span></a> &ensp; <a href="#"><span class="fa fa-share-alt"></span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $propertyinfor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propertyinfor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="default-property-box mix all for-sell col-lg-4 col-md-6 col-sm-6 col-xs-12">

                                          
                            <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><a href="<?php echo e(URL('property-details/'.$propertyinfor->property_slug)); ?>"><img src="<?php echo e(url($propertyinfor->getimg($propertyinfor->id))); ?>" alt=""></a></figure>
                                <div class="property-price">$<?php echo e($propertyinfor->prices); ?> / Month</div>
                            </div>
                            <div class="lower-content">
                                <div class="rating-review">
                                    <div class="ratings"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></div>
                                    <div class="rev">(105 reviews)</div>
                                </div>
                                <div class="property-title">
                                    <h3><a href="<?php echo e(URL('property-details/'.$propertyinfor->property_slug)); ?>"><?php echo e($propertyinfor->property_title); ?></a></h3>
                                    <div class="location"><span class="fa fa-map-marker"></span>&nbsp; <?php echo e($propertyinfor->property_location); ?>,
                                    <?php echo e($propertyinfor->city); ?>

                                    <?php echo e($propertyinfor->state); ?></div>
                                </div>
                                <div class="prop-info clearfix">
                                    <div class="prop-for"><span class="for">For <?php echo e($propertyinfor->property_type); ?></span><span class="area"><?php echo e($propertyinfor->property_area); ?> sq ft.</span></div>
                                    <div class="link-box"><a href="<?php echo e(URL('property-details/'.$propertyinfor->property_slug)); ?>" class="theme-btn">View Details <span class="fa fa-angle-right"></span></a></div>
                                </div>
                                <div class="property-meta">
                                    <ul class="clearfix">
                                        <li><span class="icon fa fa-user"></span> <?php echo e($propertyinfor->getName($propertyinfor->user_id)); ?></li>
                                        <li><span class="icon fa fa-calendar"></span> <?php echo e($propertyinfor->created_at); ?></li>
                                        <li class="options"><a href="#"><span class="fa fa-heart-o"></span></a> &ensp; <a href="#"><span class="fa fa-share-alt"></span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </div>
                 </div>
                 </div>
    </div>
    </section>

    
     
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.applayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>