<?php /* C:\xampp\htdocs\PMSE\resources\views/dynamic_dependent.blade.php */ ?>
    
    <?php $__env->startSection('content'); ?>

     <section class="home-banner with-border">
<div class="banner-slider-container">
            <ul class="banner-slider owl-theme owl-carousel">
            <li class="slide-item" style="background-image:url(assets/images/main-slider/1.jpg);"></li>
            <li class="slide-item" style="background-image:url(assets/images/main-slider/2.jpg);"></li>
            <li class="slide-item" style="background-image:url(assets/images/main-slider/3.jpg);"></li>
            </ul>
        </div>
        
        <!--Banner Search Form-->
        <div class="banner-search-container">
            <div class="form-outer">
                <div class="banner-search-form">
                    <h1>Find your dream home just in a click</h1>
                    <div class="text">“Local Real Estate / Marketed Internationally”</div>
                    
                    <div class="banner-form-box">
                        <div class="default-form">
                            <form method="post" action="http://effortthemes.com/html/lirive/properties-list-one.html">
                                <div class="row clearfix">
                                    <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                        <select class="custom-select-box">
                                            <option>Property Type</option>
                                            <option>Residential</option>
                                            <option>Commercial</option>
                                            <option>Agriculture</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6 col-sm-4 col-xs-12">
                                        <input type="text" name="field-name" value="" placeholder="Enter Location" required>
                                    </div>
                                    <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                        <button type="submit" class="theme-btn btn-style-one">SEARCH</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>
 
<div class="page-inner">
     <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                   
                    
                <div class="page-title">
                    <h3>Dynamic_Dependent</h3>
                    <div class="page-breadcrumb">
                        <ol class="breadcrumb">
                            <li class="active">Dynamic_Dependent</li>
                        </ol>
                    </div>
                </div>
                <div class="container box">
   <h3 align="center"> Dynamic Dependent Dropdown </h3><br />
   <div class="col-md-6  col-md-offset-2">
   <div class="form-group">
    <select name="country" id="country" class="form-control input-lg dynamic" data-dependent="state">
     <option value="">Select Country</option>
     <?php $__currentLoopData = $country_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <option value="<?php echo e($country->country); ?>"><?php echo e($country->country); ?></option>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
   </div>
   <br />
   <div class="form-group">
    <select name="state" id="state" class="form-control input-lg dynamic" data-dependent="city">
     <option value="">Select State</option>
    </select>
   </div>
   <br />
   <div class="form-group">
    <select name="city" id="city" class="form-control input-lg">
     <option value="">Select City</option>
    </select>
   </div>
   <?php echo e(csrf_field()); ?>

   <br />
   <br />
  </div>
</div>
</div>
 </body>
</html>

<script>
$(document).ready(function(){

 $('.dynamic').change(function(){
  if($(this).val() != '')
  {
   var select = $(this).attr("id");
   var value = $(this).val();
   var dependent = $(this).data('dependent');
   var _token = $('input[name="_token"]').val();
   $.ajax({
    url:"<?php echo e(route('dynamicdependent.fetch')); ?>",
    method:"POST",
    data:{select:select, value:value, _token:_token, dependent:dependent},
    success:function(result)
    {
     $('#'+dependent).html(result);
    }

   })
  }
 });

 $('#country').change(function(){
  $('#state').val('');
  $('#city').val('');
 });

 $('#state').change(function(){
  $('#city').val('');
 });
 

});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.applayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>