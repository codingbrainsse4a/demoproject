<?php /* C:\xampp\htdocs\PMSE\resources\views/layout/applayout.blade.php */ ?>
<!DOCTYPE html>
<html>

<!-- Mirrored from effortthemes.com/html/lirive/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 22 Jan 2019 15:31:43 GMT -->
<head>
<meta charset="utf-8">
<title>Property Management System </title>
<!-- Stylesheets -->

<?php echo Html::style('assets/css/bootstrap.css'); ?>

<?php echo Html::style('assets/css/style.css'); ?>


<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<?php echo Html::style('assets/css/responsive.css'); ?>

<?php echo Html::script('assets/plugins/3d-bold-navigation/js/modernizr.js'); ?>

<?php echo Html::script('assets/plugins/offcanvasmenueffects/js/snap.svg-min.js'); ?>

<?php echo Html::script('http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js'); ?>

<?php echo Html::script('https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.4.0/dropzone.js'); ?>

</head>

<body>

<div class="page-wrapper">

    <div class="preloader"></div>
    
   <?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


   <?php echo $__env->yieldContent('content'); ?>
  
    
   <?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-long-arrow-up"></span></div>


<?php echo html::script('assets/js/jquery.js'); ?>


<?php echo Html::script('assets/js/jquery-1.9.1.min.js'); ?>

<?php echo html::script('assets/js/bootstrap.min.js'); ?>

<?php echo html::script('assets/js/jquery-ui.js'); ?>

<?php echo html::script('assets/js/jquery.fancybox.pack.js'); ?>

<?php echo html::script('assets/js/create.js'); ?>

 
 <?php echo html::script('assets/js/jquery.fancybox-media.js'); ?>


<?php echo html::script('assets/js/mixitup.js'); ?>

<?php echo html::script('assets/js/owl.js'); ?>

<?php echo html::script('assets/js/wow.js'); ?>

<?php echo html::script('assets/js/appear.js'); ?>

<?php echo html::script('assets/js/script.js'); ?>

<?php echo html::script('assets/js/validate.js'); ?>

<?php echo html::script('assets/js/script.js'); ?>


    
</body>

<!-- Mirrored from effortthemes.com/html/lirive/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 22 Jan 2019 15:33:13 GMT -->
</html>