<?php /* C:\xampp\htdocs\PMSE\resources\views/user-profile.blade.php */ ?>
   
    <?php $__env->startSection('content'); ?>

<section class="inner-page-banner style-two" style="background-image:url(assets/images/background/bg-page-title.jpg);">
        <div class="auto-container">
            <h1>Agent Profile</h1>
            <div class="text">Reprehenderit in voluptate velit esse cillum dolore.</div>
        </div>
    </section>
    
    
    <!--Agent Details-->
    <section class="agent-details">
        <div class="auto-container">
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>


                            <?php endif; ?>

                                <?php if(Session::has('error')): ?>
                                 <div class="alert alert-danger">
                                <?php echo e(Session::get('error')); ?>

                            </div>
                                <?php endif; ?>
        <div class="row clearfix">
             <form method="post" action="my-profile-updated" enctype="multipart/form-data">
                         <?php echo e(csrf_field()); ?>

        <div class="image-column col-md-4 col-sm-6 col-xs-12">
        <figure class="image">
           <?php if(isset($profileimage)): ?>
          <?php if($profileimage->profile_image!=''): ?>
            <img src="<?php echo e($profileimage->profile_image); ?>" alt="">
             <?php endif; ?> 
            <?php else: ?>
            <img src="<?php echo e(URL('assets/images/yourphoto.jpg')); ?>" alt="">
            <?php endif; ?> 
        <br>
        <label class="control-label">Change Image :</label>
         <div>
        <input type="file" name="browse" accept="image/*"/>              
                </div>

                <br>
<br>
         <label class="control-label">Please Submit Your Id Proof :</label>
         <div>
        <input type="file" name="idProof" accept="image/*"/>
        <figure class="image">
           <?php if(isset($profileimage)): ?>
          <?php if($profileimage->id_proof!=''): ?>
            <img src="<?php echo e($profileimage->id_proof); ?>" alt="">
             <?php endif; ?>
         <?php else: ?>
         <br>
            <img src="<?php echo e(URL('assets/images/idproofsample.png')); ?>" alt="">
            <?php endif; ?> 
        </figure>               
                                
                </div>
            </div>
                
                <!--Content Column-->
                <div class="content-column col-md-8 col-sm-12 col-xs-12">
                    <div class="inner">
                        <div class="details-header clearfix">
                            <div class="row">
                                <div class=" col-md-12 ">
                                    <div class="title">
                                        <h3>Profile Information</h3>
                                        <!-- <div class="designation">Agent in Los Angeles</div> -->
                                    </div>
                                </div>
                            </div>
                           
                                <div class="row">
                                    <div class=" col-md-6 ">
                                        <div class="form-group">
                                            <label class="control-label">First Name:</label>
                                                    <input type="text" class="form-control" name="firstname" placeholder="First Name" value="<?php echo e(Auth::user()->firstname); ?>">
                                                        <?php if($errors->has('firstname')): ?>
                                                    <span class="help-block">
                                                    <strong><?php echo e($errors->first('firstname')); ?></strong>
                                                    </span>
                                                        <?php endif; ?>
                                                
                                         </div>
                                    </div>
                            </div>
                          <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">Last Name:</label>
                                                <input type="text" class="form-control" name="lastname" placeholder="last name" value="<?php echo e(Auth::user()->lastname); ?>">
                                                    <?php if($errors->has('lastname')): ?>
                                                <span class="help-block">
                                                <strong><?php echo e($errors->first('lastname')); ?></strong>
                                                </span>
                                                    <?php endif; ?>
                                           
                                     </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">Contact No:</label>
                                                <input type="text" class="form-control" name="contactno" placeholder="contactno" value="<?php echo e(Auth::user()->contactno); ?>">
                                                    <?php if($errors->has('contactno')): ?>
                                                <span class="help-block">
                                                <strong><?php echo e($errors->first('contactno')); ?></strong>
                                                </span>
                                                    <?php endif; ?>
                                             </div>
                                     </div>
                                </div>
                     

                            <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">Email:</label>
                                                <input type="text" class="form-control" name="email" placeholder="email" value="<?php echo e(Auth::user()->email); ?>">
                                                    <?php if($errors->has('email')): ?>
                                                <span class="help-block">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                                </span>
                                                    <?php endif; ?>
                                             </div>
                                     </div>
                                </div>
                        
                            <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">Adress1:</label>
                                <input type="text" class="form-control" name="address1" placeholder="address1" value=<?php echo e(old('address1')!= "" ? old('address1') : Auth::user()->address1); ?>>
                                            </div>
                                     </div>
                                </div>
                         
                            <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">Adress2:</label>
                                                <input type="text" class="form-control" name="address2" placeholder="address1" value="">
                                            </div>
                                     </div>
                                </div>
                          
                            <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">City:</label>
                                                <input type="text" class="form-control" name="city" placeholder="city" value="">
                                            </div>
                                     </div>
                                </div>
                 
                            <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">State:</label>
                                                <input type="text" class="form-control" name="state" placeholder="state" value="">
                                            </div>
                                     </div>
                                </div>
                                <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">PinCode:</label>
                                                <input type="text" class="form-control" name="pincode" placeholder="pincode" value="">
                                            </div>
                                     </div>
                                </div>
                                <div class="row">
                                <div class=" col-md-6 ">
                                    <div class="form-group">
                                        <label class="control-label">Country:</label>
                                                <input type="text" class="form-control" name="country" placeholder="country" value="">
                                            </div>
                                     </div>
                                </div>
                                 <?php echo e(csrf_field()); ?>

                           <div class="clearfix">
                                <div class="form-group pull-left">
                                    <button type="submit" class="theme-btn btn-style-one">Update</button>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                </form>
            </div>
            
        </div>
    </section>
    
    
    
    
    <!--NewsLetter Section-->
    <section class="newsletter-section with-negative-margin">
        <div class="auto-container">
            <div class="outer-box">
                <!--Heading-->
                <div class="sec-title centered">
                    <h2>Get Update</h2>
                </div>
                
                <!--Newsletter Style One-->
                <div class="newsletter-style-one">
                    <div class="desc-text">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia est deserunt mollit anim laborum. Sed perspiciatis unde omnis iste natus.</div>
                    
                    <form method="post" action="http://effortthemes.com/html/lirive/contact.html">
                        <div class="form-group">
                            <input type="email" name="text" value="" placeholder="Enter Your Email" required>
                            <button type="submit" class="theme-btn">Subscribe</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    
  

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.applayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>