<?php /* C:\xampp\htdocs\PMSE\resources\views/add-property.blade.php */ ?>
 
    <?php $__env->startSection('content'); ?>
    <section class="inner-page-banner style-two" style="background-image:url(assets/images/background/bg-page-title.jpg);">
        <div class="auto-container">
            <h1>Submit Property</h1>
            <div class="text">Reprehenderit in voluptate velit esse cillum dolore.</div>
        </div>
    </section>
    
    <!--Add Property Section-->
    <section class="add-property">
    	<div class="default-form">
            <form method="post" action="<?php echo e(URL('property_added')); ?>" enctype="multipart/form-data">

                 <?php echo e(csrf_field()); ?>

                <!--Add Property Info-->
                <div class="add-property-info">
                    <div class="auto-container">

                <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>


                            <?php endif; ?>

                                <?php if(Session::has('error')): ?>
                                 <div class="alert alert-danger">
                                <?php echo e(Session::get('error')); ?>

                            </div>
                                <?php endif; ?>
                               
                                <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                                <?php endif; ?>

                        <div class="sec-title centered"><h2>Property Information</h2></div>
                        <div class="row clearfix">
                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                <span value="<?php echo e(Auth::user()->id); ?>">
                                </span>
                            </div>
                            <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                <!-- <div class="field-label">Property Title</div> -->
                                <label for="property_title">Property Title:</label>
                                <input class="form-control" type="text" name="property_title" value="<?php echo e(old('property_title')); ?>" placeholder="" >
                                <span style="color: red">
                              <?php echo e($errors->first('property_title')); ?></span>
                            </div>
                           <!--  <span><input type="text" name="property_slug" value="" placeholder="" required>
                            </span> -->
                            <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                <label for="type">Type:</label>
                                <select class="custom-select-box" name="property_type">
                        <option>Any Status</option>
                        <option value="rent" <?php echo e(old('property_type')=='rent' ? 'selected="selected"' : ''); ?>>ForRent</option>
                        <option value="sale" <?php echo e(old('property_type')=='sale' ? 'selected="selected"' : ''); ?>>ForSale</option>
                                </select>
                                <span style="color: red">
                              <?php echo e($errors->first('property_type')); ?></span>
                            </div>

                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                         <label for="price">Price ($):</label>
                            <input type="text" name="prices" value="<?php echo e(old('prices')); ?>" placeholder="0">
                            <span style="color: red">
                              <?php echo e($errors->first('prices')); ?></span>
                        </div>
                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                <label for="area">Area (Sq. ft):</label>
                                <input type="text" name="property_area" value="<?php echo e(old('property_area')); ?>" placeholder="0">
                                <span style="color: red">
                              <?php echo e($errors->first('property_area')); ?></span>
                        </div>
                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                 <label for="property_floor">Property Floor:</label>
                                <input type="text" name="property_floor" value="<?php echo e(old('property_floor')); ?>" placeholder="">
                                 <span style="color: red">
                              <?php echo e($errors->first('property_floor')); ?></span>
                            </div>
                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                <label for="address">Address:</label>
                                <input type="text" name="property_location" value="<?php echo e(old('property_location')); ?>" placeholder="">
                                <span style="color: red">
                              <?php echo e($errors->first('property_location')); ?></span>
                        </div>
                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                <label for="area">Area:</label>
                                <input type="text" name="area" value="<?php echo e(old('area')); ?>" placeholder="">
                                <span style="color: red">
                              <?php echo e($errors->first('area')); ?></span>
                        </div>
                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                <label for="city">City:</label>
                                <input type="text" name="city" value="<?php echo e(old('city')); ?>" placeholder="">
                                 <span style="color: red">
                              <?php echo e($errors->first('city')); ?></span>
                        </div>
                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                <label for="state">State:</label>
                                <input type="text" name="state" value="<?php echo e(old('state')); ?>" placeholder="">
                                 <span style="color: red">
                              <?php echo e($errors->first('state')); ?></span>
                        </div>
                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                <label for="zipcode">Zip Code:</label>
                                <input type="text" name="pincode" value="<?php echo e(old('pincode')); ?>" placeholder="">
                                 <span style="color: red">
                              <?php echo e($errors->first('pincode')); ?></span>
                        </div>
                        <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                <label for="country">Country:</label>
                                <input type="text" name="country" value="<?php echo e(old('country')); ?>" placeholder="">
                                <span style="color: red">
                              <?php echo e($errors->first('country')); ?></span>
                        </div>   

                        <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                <label for="description">Description:</label>
                                <textarea name="property_description" placeholder=""><?php echo e(old('property_description')); ?></textarea>
                                <span style="color: red">
                              <?php echo e($errors->first('property_description')); ?></span>
                        </div>
<!-- 
                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                <div class="add-gallery">
                <div class="auto-container">
                <div class="sec-title centered"><h3>Photo/Video Gallery</h3></div>
                <div class="upload-panel">
                <div class="icon"><span class="fa fa-plus"></span></div>
            <div class="text">Click here or drop files to upload</div>
                </div>
                    </div>
                    </div>
                </div>-->
<div class="form-group col-md-12 col-sm-12 col-xs-12">
                               
                                <label for="mediatype">Media Type:</label>
                                <select class="custom-select-box" name="media_type">
                        <option >Media Type</option>
                        <option  value="image" <?php echo e(old('media_type')=='image' ? 'selected="selected"' : ''); ?>>Image</option>
                        <option value="video" <?php echo e(old('media_type')=='video' ? 'selected="selected"' : ''); ?>>Video</option>
                                </select>
                              <span style="color: red">
                              <?php echo e($errors->first('media_type')); ?></span>
                            </div>

 <div class="form-group">
       
       <label class="control-label col-md-3 col-sm-3 col-xs-12">
       Property Media Image:</label>

                            <div class="col-md-9 col-sm-9 col-xs-12">
                                <!-- <div id="file_upload"> -->
                                <input type="file" name="mediaimage[]" accept="image/*" multiple/>  
<!--                                 <a id="add_more" href="#">Add more</a> -->  <!-- </div>      -->                
                                <p>Image/Video type : jpeg,png,jpg,mkv, and file size : Max 5MB</p>
                                <span>(Only 9 Images are Allowed to upload .Select Multiple files by holding Ctrl Button.)</span> 
                            </div>
                        </div>

                        <?php echo e(csrf_field()); ?>


                       
                        <div class="form-group col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group pull-center">
                                <button type="submit" class="theme-btn btn-style-one">Submit</button>
                        </div> 
                    </div>
                       


                        </div>
                    </div>
                </div>
                


            </form>
        </div>
    </section>
    
    
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.applayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>