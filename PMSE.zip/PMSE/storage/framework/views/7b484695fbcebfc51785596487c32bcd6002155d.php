<?php /* C:\xampp\htdocs\PMSE\resources\views/contactus.blade.php */ ?>
 
    <?php $__env->startSection('content'); ?>
    
    <!--Inner Page Banner-->
    <section class="inner-page-banner style-two" style="background-image:url(assets/images/background/bg-page-title.jpg);">
        <div class="auto-container">
            <h1>Contact Us</h1>
            <div class="text">Reprehenderit in voluptate velit esse cillum dolore.</div>
        </div>
    </section>
    
    
    <!--Contact Section-->
    <div class="contact-section">
        <div class="auto-container">
            <div class="outer-box clearfix">
				
                <!--Form Column-->
                <div class="form-column col-md-8 col-sm-12 col-xs-12">
                	<div class="inner">

                        <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>

                           <?php endif; ?>

                        <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(Session::get('error')); ?>

                        </div>
                               <?php endif; ?>
                    	<div class="title"><h2>Send Us Message</h2></div>
                        <!-- Contact Form -->
                        <div class="contact-form">
                            <form method="post" id="contact-form" action="<?php echo e(URL('send_information')); ?>">
                                 <?php echo e(csrf_field()); ?>

                        <div class="row clearfix">

                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group">
                                        <label for="name">Name:</label>
                                        <input class="form-control" type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="Please Enter Your Name">
                                        <span style="color: red">
                                    <?php echo e($errors->first('name')); ?>

                                       </span>  
                                    </div>
    
                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group">
                                        <label for="email">Email:</label>
                                        <input class="form-control" type="email" name="email_id" value="<?php echo e(old('email_id')); ?>" placeholder="Please Enter Your Email Id">
                                        <span style="color: red">
                                    <?php echo e($errors->first('email_id')); ?>

                                       </span>  
                                    </div>
                                    
                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group">
                                        <label for="contact_no">Contact_No:</label>
                                        <input class="form-control" type="text" name="contact_no" value="<?php echo e(old('contact_no')); ?>" placeholder="Please Enter Your Phone No.">
                                        <span style="color: red">
                                    <?php echo e($errors->first('contact_no')); ?>

                                       </span>        
                                    </div>
                                    
                                    <div class="col-md-6 col-sm-6 col-xs-12 form-group">
                                        <label for="subject">Subject:</label>
                                        <input class="form-control" type="text" name="subject" value="<?php echo e(old('subject')); ?>" placeholder="Please Enter Your Subject" >
                                        <span style="color: red">
                                    <?php echo e($errors->first('subject')); ?>

                                       </span> 
                                    </div>
    
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 form-group">
                                        <label for="message">Message:</label>
                                        <textarea class="form-control" name="message" value="" placeholder="Please Enter Your Message"><?php echo e(old('message')); ?></textarea>
                                        <span style="color: red">
                                    <?php echo e($errors->first('message')); ?>   
                                       </span> 
                                    </div>
                                 <?php echo e(csrf_field()); ?>

                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 form-group">
                                        <button class="theme-btn btn-style-one" type="submit" name="submit-form">Send Message</button>
                                    </div>
    
                                </div>
                            </form>
    
                        </div>
                        <!--End Contact Form -->
                    </div>
                </div>
                
                <!--Info Column-->
                <div class="info-column col-md-4 col-sm-12 col-xs-12">
                	<div class="inner">
                    	<div class="title"><h2>Contact Information</h2></div>
                        <ul class="contact-info">
                        	<li><div class="icon-box"><span class="fa fa-map-marker"></span></div> 2/1 Vipul Khand Gomti Nagar <br>Lucknow Uttar Pradesh </li>
                            <li><div class="icon-box"><span class="fa fa-phone"></span></div> +880 111 234 4567 <br>+91 111 234 4568</li>
                            <li><div class="icon-box"><span class="fa fa-envelope"></span></div> support@pms.com</li>
                        </ul>
                        
                        <!--Social Links-->
                        <!-- <ul class="social-links clearfix">
                        	<li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                            <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                        </ul> -->
                    </div>
                </div>

            </div>
        </div>
    </div>
    
    <!--Map Section-->
    <section class="map-section">
    	<!--Map Box-->
        <div class="map-box">
            <!--Map Canvas-->
            <div class="map-canvas"
                data-zoom="8"
                data-lat="-37.817085"
                data-lng="144.955631"
                data-type="roadmap"
                data-hue="#ffc400"
                data-title="Envato"
                data-content="Melbourne VIC 3000, Australia<br><a href='mailto:info@youremail.com'>info@youremail.com</a>">
            </div>
        </div>
    </section>
<!--Google Map APi Key-->
<script src="http://maps.google.com/maps/api/js?key=AIzaSyBKS14AnP3HCIVlUpPKtGp7CbYuMtcXE2o"></script>

<!-- <script src="js/map-script.js"></script> -->
<!--End Google Map APi-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.applayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>