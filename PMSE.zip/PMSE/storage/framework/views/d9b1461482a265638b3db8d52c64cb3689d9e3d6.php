<?php /* C:\xampp\htdocs\PMSE\resources\views/new-blog.blade.php */ ?>
 
    <?php $__env->startSection('content'); ?>
    
                  <script src="<?php echo e(asset('vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
                  <!--Inner Page Banner-->
                  <section class="inner-page-banner style-two" style="background-image:url(assets/images/background/bg-page-title.jpg);">
                      <div class="auto-container">
                          <h1> </h1>
                          <div class="text">Duis aute irure dolor in reprehenderit</div>
                      </div>
                  </section>
                
                  <section class="register-section">
                    <div class="auto-container">
                    <div class="row clearfix">
                         <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                          <?php echo e(Session::get('success')); ?>

                       </div>
                          <?php endif; ?>

                          <?php if(Session::has('error')): ?>
                       <div class="alert alert-danger">
                          <?php echo e(Session::get('error')); ?>

                       </div>
                          <?php endif; ?>
                       <div class="sec-title medium">
                        <h2></h2>
                       </div>
                     
                        <div class="styled-form register-form">
                        <form method="post" action="<?php echo e(URL('blog-added')); ?>" enctype="multipart/form-data">
                         <?php echo e(csrf_field()); ?>

                        <div class="form-group col-md-10">
                        <div class="form-group col-md-18">
                        <div class="form-group">
                        <select class="custom-select-box" name="blog_type">
                        <option value="">Select  Type</option>
                        <option value="Bussiness">Bussiness</option>
                        <option value="Lifestyle">Lifestyle</option>
                        <option value="Photography">Photography</option>
                        <option value="Property News">Property News</option>
                        <option value="Our Thoughts">Our Thoughts</option>
                        <span style="color: red">
                              <?php echo e($errors->first('blog_type')); ?></span>
                        </select>

                        </div>

                        <div class="form-group">
                        <label for="news_title">Blog Title *:</label>
                        <input type="text" name="blog_title" class="form-control value="" placeholder="Please write Title" >
                        <span style="color: red">
                          <?php echo e($errors->first('blog_title')); ?></span>
                        </div>
                        <div class="form-group">Discription
                          <textarea class="form-control" value="" id="summary-ckeditor" name="blog_description" placeholder="Please Enter your Description"></textarea>
                                
                          <span style="color: red">
                              <?php echo e($errors->first('blog_description')); ?></span>
                          </div>
                          <div class="form-group">Blog Image
                          <input type="file" name="blogimage" accept="image/*"/>    
                          </div> 
                            <?php echo e(csrf_field()); ?>  
                                     

                           <div class="clearfix">
                           <div class="form-group pull-left">
                           <button type="submit" class="theme-btn btn-style-one">Submit</button>
                           </div>
                           </div>
                            </div>
                            </div>
                            </form>
                            </div>
                                    
                                
                              
                            </div>
                            </div>
                          </section>
                          <script>CKEDITOR.replace( 'summary-ckeditor' );
                          </script>
                          <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.applayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>