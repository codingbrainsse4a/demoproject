<?php /* C:\xampp\htdocs\PMSE\resources\views/my-property.blade.php */ ?>
 
    <?php $__env->startSection('content'); ?>

    <!--Inner Page Banner-->
    <section class="inner-page-banner" style="background-image:url(assets/images/background/bg-page-title.jpg);">
        <div class="auto-container">
            <h1>Search Your Home</h1>
            <div class="text">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore.</div>
            
            <div class="banner-form-box medium">
                <div class="default-form">
                    <!-- <form method="post" action="http://effortthemes.com/html/lirive/agents.html"> -->
                        <div class="row clearfix">
                            <div class="form-group col-md-9 col-sm-8 col-xs-12">
                                <input type="text" name="field-name" value="" placeholder="Enter Location" required>
                            </div>
                            <div class="form-group col-md-3 col-sm-4 col-xs-12">
                                <button type="submit" class="theme-btn btn-style-one">SEARCH</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
        </div>
    </section>
    
    
    <!--Properties Search Section-->
    <section class="properties-search-section">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Posts Column-->
                <div class="posts-column col-lg-8 col-md-12 col-sm-12 col-xs-12">
                    <div class="upper-filters clearfix">
                        <!--Form Column-->
                        <div class="form-column">
                            <div class="default-form">
                                <form method="post" action="">
                                	<div class="option-box sort-by">
                                        <div class="sel-label">Sort By</div>
                                        <div class="form-group">
                                            <select class="custom-select-box">
                                                <option>Newest Item</option>
                                                <option>By Price</option>
                                                <option>By Ratings</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="option-box">
                                        <div class="sel-label">View</div>
                                        <div class="form-group">
                                            <select class="custom-select-box">
                                                <option>List</option>
                                                <option>Grid</option>
                                            </select>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!--Count Column-->
                        <div class="count-column">
                            <div class="count">42 homes found</div>
                        </div>
                        
                    </div>
                    
                    <div class="listing">
                    	<!--Default Property Box / List View-->

                        <?php $__currentLoopData = $propertyinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="default-property-box list-view">
                            <div class="inner-box clearfix">
                            	<!--Image Column-->
                                <div class="image-column col-md-6 col-sm-6 col-xs-12">
                                    <div class="image-box">
                                        <figure class="image"><a href=""><img src="<?php echo e(url($property_list->getimg($property_list->id))); ?>"alt=""></a></figure>
                                        <div class="property-price"><?php echo e($property_list->prices); ?> /Month</div>
                                    </div>
                                </div>
                                <!--Content Column-->
                                <div class="content-column col-md-6 col-sm-6 col-xs-12">
                                    <div class="lower-content">
                                        <div class="rating-review">
                                            <div class="ratings"><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span></div>
                                            <div class="rev">(105 reviews)</div>
                                        </div>
                                        <div class="property-title">
                                            <h3><a href="<?php echo e(URL('property-details/'.$property_list->property_slug)); ?>"><?php echo e($property_list->property_title); ?></a></h3>
                                            <div class="location"><span class="fa fa-map-marker"></span>&nbsp; <?php echo e($property_list->property_location); ?>, 
                                            <?php echo e($property_list->city); ?>-
                                            <?php echo e($property_list->state); ?>

                                     </div>
                                        </div>
                                        <div class="prop-info clearfix">
                                            <div class="prop-for"><span class="for"><?php echo e($property_list->property_type); ?></span><span class="area"><?php echo e($property_list->property_area); ?> sq. ft</span></div>
                                            <div class="link-box"><a href="<?php echo e(URL('property-details/'.$property_list->property_slug)); ?>" class="theme-btn">View Details <span class="fa fa-angle-right"></span></a></div>
                                        </div>
                                        <div class="property-meta">
                                            <ul class="clearfix">
                                                <li><span class="icon fa fa-user"></span> <?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->lastname); ?></li>
                                                <li><span class="icon fa fa-calendar"></span> <?php echo e($property_list->created_at); ?></li>
                                                <li class="options"><a href="#"><span class="fa fa-heart-o"></span></a> &ensp; <a href="#"><span class="fa fa-share-alt"></span></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                                       
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.applayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>