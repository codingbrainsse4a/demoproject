<?php /* C:\xampp\htdocs\PMSE\resources\views/common/header.blade.php */ ?>
 <header class="main-header">
        
        <div class="main-box">
            <div class="outer-container clearfix">
                
                <!--Logo Box-->
                <div class="logo-box">
                    <div class="logo"><a href="<?php echo e(URL('/')); ?>" title="Lirive"><img src="<?php echo e(url('assets/images/logo.png')); ?>" alt="Lirive" title="Lirive"></a></div>
                </div>
                
                <!--Other Links-->
                <div class="other-links clearfix">
                    <?php if(Auth::Check()): ?>
                   <section>
                    <a href="#" class="dropdown-toggle waves-effect waves-button waves-classic" data-toggle="dropdown">
                            <span class="user-name"><?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->lastname); ?><i class="fa fa-angle-down"></i></span>
                            &nbsp; 
                            <?php if(isset($profileimage)): ?>
                                <?php if($profileimage->profile_image!=''): ?>
                                <img class="img-circle avatar"  src="<?php echo e($profileimage->profile_image); ?>" width="65" height="65" alt="">
                               
                                 
                             <?php endif; ?>
                              <?php else: ?>
                                 <img class="img-circle avatar" src="<?php echo e(URL('assets/images/profilelogopic.jpg')); ?>" width="65" height="55" alt="">
                            <?php endif; ?>


                    </a>
                    <ul class="dropdown-menu dropdown-list" role="menu">
                                        <li role="presentation"><a href="<?php echo e(URL('my-profile')); ?>"><i class="fa fa-user"></i>Profile</a></li>
                                        <li role="presentation"><a href="<?php echo e(URL('logout')); ?>"><i class="fa fa-sign-out m-r-xs"></i>Log out</a></li>
                                    </ul>
                                </section>
                       <?php else: ?>
                    <div class="link-box"><a class="add-property-btn theme-btn" href="<?php echo e(URL('login')); ?>">Login</a></div>
                    <div class="link-box"><a class="add-property-btn theme-btn" href="<?php echo e(URL('register')); ?>">Register For new User</a></div>
                    <?php endif; ?>
                </div>

                <!--Nav Outer-->
                <div class="nav-outer clearfix">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->    	
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="dropdown"><a href="<?php echo e(URL('/')); ?>">Home</a>
                                    <ul>
                                        <li><a href="<?php echo e(URL('Home-Page')); ?>">Home1</a>
                                </li>
                            </ul>
                                </li>
                                
                                <li><a href="<?php echo e(URL('aboutus')); ?>">About Us</a>
                                </li>

                                <li><a href="<?php echo e(URL('search-property')); ?>">Search Property</a>
                                </li>
                        <?php if(Auth::Check()): ?>
                                <li class="dropdown"><a href="<?php echo e(URL('')); ?>">My Account</a>
                                    <ul>
                                        <li><a href="<?php echo e(URL('my-profile')); ?>">My Profile</a></li>
                                        <?php if(Auth::user()->user_type == 1): ?>

                                        <li><a href="<?php echo e(URL('my-property-list')); ?>">My Property</a></li>
                                        <li><a href="<?php echo e(URL('add-property')); ?>">Add Property</a></li>
                                        <?php endif; ?>
                                    </ul>
                                </li>
                                <?php endif; ?>
                                <li><a href="<?php echo e(URL('contactus')); ?>">Contact Us</a></li>
                             </ul>
                        </div>
                    </nav><!-- Main Menu End-->
                    
                </div>
                <!--Nav Outer End-->
                
            </div>
        </div>
    
    </header>