<?php /* C:\xampp\htdocs\PMSE\resources\views/layouts/app.blade.php */ ?>
<!DOCTYPE html>
<html>

<head>
        
        <!-- Title -->
        <title>Modern | Admin Dashboard Template</title>
        
        <meta content="width=device-width, initial-scale=1" name="viewport"/>
        <meta charset="UTF-8">
        <meta name="description" content="Admin Dashboard Template" />
        <meta name="keywords" content="admin,dashboard" />
        <meta name="author" content="Steelcoders" />
        
        <!-- Styles -->
       

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.4.0/min/dropzone.min.css">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'>


        <?php echo Html::style('admin/assets/plugins/pace-master/themes/blue/pace-theme-flash.css'); ?>

         <?php echo Html::style('admin/assets/plugins/uniform/css/uniform.default.min.css'); ?>

          <?php echo Html::style('admin/assets/plugins/bootstrap/css/bootstrap.min.css'); ?>

          <?php echo Html::style('admin/assets/plugins/fontawesome/css/font-awesome.css'); ?>

           <?php echo Html::style('admin/assets/plugins/line-icons/simple-line-icons.css'); ?>

           <?php echo Html::style('admin/assets/plugins/offcanvasmenueffects/css/menu_cornerbox.css'); ?>

            <?php echo Html::style('admin/assets/plugins/waves/waves.min.css'); ?>

    <?php echo Html::style('admin/assets/plugins/switchery/switchery.min.css'); ?>

    <?php echo Html::style('admin/assets/plugins/3d-bold-navigation/css/style.css'); ?>

     <?php echo Html::style('admin/assets/plugins/slidepushmenus/css/component.css'); ?>

     <?php echo Html::style('admin/assets/plugins/weather-icons-master/css/weather-icons.min.css'); ?>

     <?php echo Html::style('admin/assets/plugins/metrojs/MetroJs.min.css'); ?>

     <?php echo Html::style('admin/assets/plugins/toastr/toastr.min.css'); ?>

      
        
            
        <!-- Theme Styles -->
 <?php echo Html::style('admin/assets/css/modern.min.css'); ?>

 <?php echo Html::style('admin/assets/css/themes/green.css'); ?>

 <?php echo Html::style('admin/assets/css/custom.css'); ?>


      

         <?php echo Html::script('admin/assets/plugins/3d-bold-navigation/js/modernizr.js'); ?>

         <?php echo Html::script('assets/plugins/offcanvasmenueffects/js/snap.svg-min.js'); ?>

         <?php echo Html::script('http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js'); ?>

         <?php echo Html::script('https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.4.0/dropzone.js'); ?>



        
    </head>
        <div class="overlay"></div>
    <body class="page-header-fixed">
        <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right" id="cbp-spmenu-s1">
            <h3><span class="pull-left">Chat</span><a href="javascript:void(0);" class="pull-right" id="closeRight"><i class="fa fa-times"></i></a></h3>
            <div class="slimscroll">
                <a href="javascript:void(0);" class="showRight2"><img src="admin/assets/images/avatar2.png" alt=""><span>Sandra smith<small>Hi! How're you?</small></span></a>
                <a href="javascript:void(0);" class="showRight2"><img src="admin/assets/images/avatar3.png" alt=""><span>Amily Lee<small>Hi! How're you?</small></span></a>
                <a href="javascript:void(0);" class="showRight2"><img src="admin/assets/images/avatar4.png" alt=""><span>Christopher Palmer<small>Hi! How're you?</small></span></a>
                <a href="javascript:void(0);" class="showRight2"><img src="admin/assets/images/avatar5.png" alt=""><span>Nick Doe<small>Hi! How're you?</small></span></a>
                <a href="javascript:void(0);" class="showRight2"><img src="admin/assets/images/avatar2.png" alt=""><span>Sandra smith<small>Hi! How're you?</small></span></a>
                <a href="javascript:void(0);" class="showRight2"><img src="admin/assets/images/avatar3.png" alt=""><span>Amily Lee<small>Hi! How're you?</small></span></a>
                <a href="javascript:void(0);" class="showRight2"><img src="admin/assets/images/avatar4.png" alt=""><span>Christopher Palmer<small>Hi! How're you?</small></span></a>
                <a href="javascript:void(0);" class="showRight2"><img src="admin/assets/images/avatar5.png" alt=""><span>Nick Doe<small>Hi! How're you?</small></span></a>
            </div>
        </nav>
        <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right" id="cbp-spmenu-s2">
            <h3><span class="pull-left">Sandra Smith</span> <a href="javascript:void(0);" class="pull-right" id="closeRight2"><i class="fa fa-angle-right"></i></a></h3>
            <div class="slimscroll chat">
                <div class="chat-item chat-item-left">
                    <div class="chat-image">
                        <img src="admin/assets/images/avatar2.png" alt="">
                    </div>
                    <div class="chat-message">
                        Hi There!
                    </div>
                </div>
                <div class="chat-item chat-item-right">
                    <div class="chat-message">
                        Hi! How are you?
                    </div>
                </div>
                <div class="chat-item chat-item-left">
                    <div class="chat-image">
                        <img src="admin/assets/images/avatar2.png" alt="">
                    </div>
                    <div class="chat-message">
                        Fine! do you like my project?
                    </div>
                </div>
                <div class="chat-item chat-item-right">
                    <div class="chat-message">
                        Yes, It's clean and creative, good job!
                    </div>
                </div>
                <div class="chat-item chat-item-left">
                    <div class="chat-image">
                        <img src="admin/assets/images/avatar2.png" alt="">
                    </div>
                    <div class="chat-message">
                        Thanks, I tried!
                    </div>
                </div>
                <div class="chat-item chat-item-right">
                    <div class="chat-message">
                        Good luck with your sales!
                    </div>
                </div>
            </div>
            <div class="chat-write">
                <form class="form-horizontal" action="javascript:void(0);">
                    <input type="text" class="form-control" placeholder="Say something">
                </form>
            </div>
        </nav>
        <div class="menu-wrap">
            <nav class="profile-menu">
                <div class="profile"><img src="admin/assets/images/profile-menu-image.png" width="60" alt="David Green"/><span>David Green</span></div>
                <div class="profile-menu-list">
                    <a href="#"><i class="fa fa-star"></i><span>Favorites</span></a>
                    <a href="#"><i class="fa fa-bell"></i><span>Alerts</span></a>
                    <a href="#"><i class="fa fa-envelope"></i><span>Messages</span></a>
                    <a href="#"><i class="fa fa-comment"></i><span>Comments</span></a>
                </div>
            </nav>
            <button class="close-button" id="close-button">Close Menu</button>
        </div>
        <form class="search-form" action="#" method="GET">
            <div class="input-group">
                <input type="text" name="search" class="form-control search-input" placeholder="Search...">
                <span class="input-group-btn">
                    <button class="btn btn-default close-search waves-effect waves-button waves-classic" type="button"><i class="fa fa-times"></i></button>
                </span>
            </div><!-- Input Group -->
        </form><!-- Search Form -->
        <main class="page-content content-wrap">
            <?php echo $__env->make('commons.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('commons.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

           

                    <?php echo $__env->yieldContent('content'); ?>
                
                <div class="page-footer">
                    <p class="no-s">2015 &copy; Modern by Steelcoders.</p>
                </div>
            </div><!-- Page Inner -->
        </main><!-- Page Content -->

        <div class="cd-overlay"></div>
    

        <!-- Javascripts -->
    <?php echo Html::script('admin/assets/plugins/jquery/jquery-2.1.4.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/jquery-ui/jquery-ui.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/pace-master/pace.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/jquery-blockui/jquery.blockui.js'); ?>

    <?php echo Html::script('admin/assets/plugins/bootstrap/js/bootstrap.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/switchery/switchery.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/uniform/jquery.uniform.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/offcanvasmenueffects/js/classie.js'); ?>

    <?php echo Html::script('admin/assets/plugins/offcanvasmenueffects/js/main.js'); ?>

    <?php echo Html::script('admin/assets/plugins/waves/waves.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/3d-bold-navigation/js/main.js'); ?>

    <?php echo Html::script('admin/assets/plugins/waypoints/jquery.waypoints.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/jquery-counterup/jquery.counterup.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/toastr/toastr.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/flot/jquery.flot.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/flot/jquery.flot.time.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/flot/jquery.flot.symbol.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/flot/jquery.flot.resize.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/flot/jquery.flot.tooltip.min.js'); ?>

    <?php echo Html::script('admin/assets/plugins/curvedlines/curvedLines.js'); ?>

    <?php echo Html::script('admin/assets/plugins/metrojs/MetroJs.min.js'); ?>

    <?php echo Html::script('admin/assets/js/modern.js'); ?>

    <?php echo Html::script('admin/assets/js/pages/dashboard.js'); ?>

     <?php echo Html::script('admin/assets/js/pages/coming-soon.js'); ?>

     <?php echo Html::script('admin/assets/plugins/jquery-countdown/jquery.countdown.min.js'); ?>



    </body>

<!-- Mirrored from steelcoders.com/modern/admin1/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 21 Dec 2017 18:27:48 GMT -->
</html>