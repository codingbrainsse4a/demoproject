<?php /* C:\xampp\htdocs\PMSE\resources\views/sidebar/side-property-details.blade.php */ ?>
<div class="sidebar-side col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <aside class="sidebar">

                        <!-- Request Quote Form -->
           <div class="sidebar-widget request-quote">
        <div class="widget-inner">
        <div class="agent-info">
        <figure class="author-thumb img-circle">
        <?php if(isset($user)): ?>
        <?php if($user->getUserProfile->profile_image!=''): ?>
     <img class="img-circle" src="<?php echo e($user->getUserProfile->profile_image); ?>"width="95" height="95" alt="">
        <?php endif; ?>
              <?php else: ?>
                <img class="img-circle" src="<?php echo e(URL('assets/images/profilelogopic.jpg')); ?>" alt="">
              <?php endif; ?>

         </figure>
         <h3>
                                        
     <?php echo e($user->getUser->firstname); ?> 
     <?php echo e($user->getUser->lastname); ?></h3>
        <div class="designation">
        <?php if($user->getUser->user_type == '1'): ?><span>Property Manager</span>

       <?php else: ?>
    <span>Customer</span>

    <?php endif; ?>

         <span>in <?php echo e($user->getUserProfile->city); ?> <?php echo e($user->getUserProfile->state); ?></span>
         </div>
         <div class="phone"><span class="fa fa-phone"></span> <?php echo e($user->getUser->contactno); ?></div>
         </div>
         <div class="default-form quote-form">
         <h4>Request A Quote</h4>
         <form method="post" action="http://effortthemes.com/html/lirive/contact.html">
         <div class="form-group">
         <input type="text" name="field-name" value="" placeholder="Name" required >
         </div>
         <div class="form-group">
      <input type="email" name="field-name" value="" placeholder="Email" required >
        </div>
      <div class="form-group">
                                            <textarea name="field-name" placeholder="Message" required ></textarea>
                                        </div>
                                        <div class="button-group"><button type="submit" class="theme-btn btn-style-one">Send Message</button></div>
                                    </form>
                                </div>
                            </div>

                        </div>
                        
                        <!-- Recommended Properties -->
                        <div class="sidebar-widget recommended-properties">
                            <div class="sidebar-title"><h3>Recomended For You</h3></div>

                            <div class="post">
                                <figure class="post-thumb"><a href="#"><img src="assets/images/resource/post-thumb-5.jpg" alt=""></a></figure>
                                <h4><a href="#">146 Woodhaven Preserve</a></h4>
                                <ul class="specs clearfix">
                                    <li>3 Beds</li>
                                    <li>2 Baths</li>
                                    <li>1600 sq ft.</li>
                                </ul>
                                <div class="price">$25,000</div>
                            </div>

                            <div class="post">
                                <figure class="post-thumb"><a href="#"><img src="assets/images/resource/post-thumb-6.jpg" alt=""></a></figure>
                                <h4><a href="#">146 Woodhaven Preserve</a></h4>
                                <ul class="specs clearfix">
                                    <li>3 Beds</li>
                                    <li>2 Baths</li>
                                    <li>1600 sq ft.</li>
                                </ul>
                                <div class="price">$25,000</div>
                            </div>
                            
                            <div class="post">
                                <figure class="post-thumb"><a href="#"><img src="assets/images/resource/post-thumb-7.jpg" alt=""></a></figure>
                                <h4><a href="#">146 Woodhaven Preserve</a></h4>
                                <ul class="specs clearfix">
                                    <li>3 Beds</li>
                                    <li>2 Baths</li>
                                    <li>1600 sq ft.</li>
                                </ul>
                                <div class="price">$25,000</div>
                            </div>
                            
                            <div class="post">
                                <figure class="post-thumb"><a href="#"><img src="assets/images/resource/post-thumb-8.jpg" alt=""></a></figure>
                                <h4><a href="#">146 Woodhaven Preserve</a></h4>
                                <ul class="specs clearfix">
                                    <li>3 Beds</li>
                                    <li>2 Baths</li>
                                    <li>1600 sq ft.</li>
                                </ul>
                                <div class="price">$25,000</div>
                            </div>

                        </div>

                    </aside>


                </div>

                <!--Sidebar-->