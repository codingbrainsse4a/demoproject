<?php /* C:\xampp\htdocs\PMSE\resources\views/blog.blade.php */ ?>
 
    <?php $__env->startSection('content'); ?>
    
    <!--Inner Page Banner-->
    <section class="inner-page-banner style-two" style="background-image:url(assets/images/background/bg-page-title.jpg);">
        <div class="auto-container">
            <h1>Blog</h1>
            <div class="text">Duis aute irure dolor in reprehenderit</div>
        </div>
    </section>
        
    <!--Sidebar Page-->
    <div class="sidebar-page-container">
        <div class="auto-container">
            <div class="row clearfix">
				
                <!--Content Side-->
                <div class="content-side col-lg-8 col-md-8 col-sm-12 col-xs-12">
                    <section class="blog">
						
                        <div class="row clearfix">
            	
                            <!--News Style One-->
                            <div class="news-style-one col-md-6 col-sm-6 col-xs-12">
                                <div class="inner-box">
                                    <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-4.jpg" alt=""></a></figure>
                                    <div class="lower-content">
                                        <div class="post-meta">
                                            <ul>
                                                <li>26 March 2017 By Author</li>
                                            </ul>
                                        </div>
                                        <h3><a href="blog-details.html">Excepteur sint occaecat cupidatat</a></h3>
                                        <div class="text">Accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--News Style One-->
                            <div class="news-style-one col-md-6 col-sm-6 col-xs-12">
                                <div class="inner-box">
                                    <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-5.jpg" alt=""></a></figure>
                                    <div class="lower-content">
                                        <div class="post-meta">
                                            <ul>
                                                <li>26 March 2017 By Author</li>
                                            </ul>
                                        </div>
                                        <h3><a href="blog-details.html">Nemo enim ipsam voluptatem</a></h3>
                                        <div class="text">Accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--News Style One-->
                            <div class="news-style-one col-md-6 col-sm-6 col-xs-12">
                                <div class="inner-box">
                                    <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-6.jpg" alt=""></a></figure>
                                    <div class="lower-content">
                                        <div class="post-meta">
                                            <ul>
                                                <li>26 March 2017 By Author</li>
                                            </ul>
                                        </div>
                                        <h3><a href="blog-details.html">Voluptatem quia voluptas sit</a></h3>
                                        <div class="text">Accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--News Style One-->
                            <div class="news-style-one col-md-6 col-sm-6 col-xs-12">
                                <div class="inner-box">
                                    <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-7.jpg" alt=""></a></figure>
                                    <div class="lower-content">
                                        <div class="post-meta">
                                            <ul>
                                                <li>26 March 2017 By Author</li>
                                            </ul>
                                        </div>
                                        <h3><a href="blog-details.html">Excepteur sint occaecat cupidatat</a></h3>
                                        <div class="text">Accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--News Style One-->
                            <div class="news-style-one col-md-6 col-sm-6 col-xs-12">
                                <div class="inner-box">
                                    <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-8.jpg" alt=""></a></figure>
                                    <div class="lower-content">
                                        <div class="post-meta">
                                            <ul>
                                                <li>26 March 2017 By Author</li>
                                            </ul>
                                        </div>
                                        <h3><a href="blog-details.html">Nemo enim ipsam voluptatem</a></h3>
                                        <div class="text">Accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--News Style One-->
                            <div class="news-style-one col-md-6 col-sm-6 col-xs-12">
                                <div class="inner-box">
                                    <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-9.jpg" alt=""></a></figure>
                                    <div class="lower-content">
                                        <div class="post-meta">
                                            <ul>
                                                <li>26 March 2017 By Author</li>
                                            </ul>
                                        </div>
                                        <h3><a href="blog-details.html">Voluptatem quia voluptas sit</a></h3>
                                        <div class="text">Accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--News Style One-->
                            <div class="news-style-one col-md-6 col-sm-6 col-xs-12">
                                <div class="inner-box">
                                    <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-10.jpg" alt=""></a></figure>
                                    <div class="lower-content">
                                        <div class="post-meta">
                                            <ul>
                                                <li>26 March 2017 By Author</li>
                                            </ul>
                                        </div>
                                        <h3><a href="blog-details.html">Excepteur sint occaecat cupidatat</a></h3>
                                        <div class="text">Accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae.</div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--News Style One-->
                            <div class="news-style-one col-md-6 col-sm-6 col-xs-12">
                                <div class="inner-box">
                                    <figure class="image-box"><a href="blog-details.html"><img src="assets/images/resource/blog-image-11.jpg" alt=""></a></figure>
                                    <div class="lower-content">
                                        <div class="post-meta">
                                            <ul>
                                                <li>26 March 2017 By Author</li>
                                            </ul>
                                        </div>
                                        <h3><a href="blog-details.html">Nemo enim ipsam voluptatem</a></h3>
                                        <div class="text">Accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae.</div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        
                        
                        <!-- Styled Pagination -->
                        <div class="styled-pagination">
                            <ul>
                                <li><a href="#" class="active">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                                <li><a href="#" class="next">Next</a></li>
                            </ul>
                        </div>
                
                    </section>


                </div>
                <!--Content Side-->
                
                <!--Sidebar-->
                <div class="sidebar-side col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <aside class="sidebar">

                        <!-- Search Form -->
                        <div class="sidebar-widget search-box">

                            <form method="post" action="http://effortthemes.com/html/lirive/blog.html">
                                <div class="form-group">
                                    <input type="search" name="search-field" value="" placeholder="Search...">
                                    <button type="submit"><span class="icon fa fa-search"></span></button>
                                </div>
                            </form>

                        </div>


                        <!-- Recent Articles -->
                        <div class="sidebar-widget categories">
                            <div class="sidebar-title"><h3>Categories</h3></div>

                            <ul class="list">
                                <li><a href="#">Business Post (06)</a></li>
                                <li><a href="#">Lifestyle (12)</a></li>
                                <li><a href="#">Recipe Tips (08)</a></li>
                                <li><a href="#">Photography (15)</a></li>
                                <li><a href="#">Uncategorized (10)</a></li>
                            </ul>

                        </div>


                        <!-- Popular Posts -->
                        <div class="sidebar-widget popular-posts">
                            <div class="sidebar-title"><h3>Recent Posts</h3></div>

                            <article class="post">
                            	<figure class="post-thumb"><a href="#"><img src="assets/images/resource/post-thumb-1.jpg" alt=""></a></figure>
                                <h4><a href="#">Lorem ipsum dolor sit amet consectetur adipisicing.</a></h4>
                                <div class="post-info">26 March 2017</div>
                            </article>

                            <article class="post">
                            	<figure class="post-thumb"><a href="#"><img src="assets/images/resource/post-thumb-2.jpg" alt=""></a></figure>
                                <h4><a href="#">Sed do eiusmod tempor incididunt ut labore et dolore.</a></h4>
                                <div class="post-info">26 March 2017</div>
                            </article>
                            
                            <article class="post">
                            	<figure class="post-thumb"><a href="#"><img src="assets/images/resource/post-thumb-3.jpg" alt=""></a></figure>
                                <h4><a href="#">Lorem ipsum dolor sit amet consectetur adipisicing.</a></h4>
                                <div class="post-info">26 March 2017</div>
                            </article>
                            
                            <article class="post">
                            	<figure class="post-thumb"><a href="#"><img src="assets/images/resource/post-thumb-4.jpg" alt=""></a></figure>
                                <h4><a href="#">Sed do eiusmod tempor incididunt ut labore et dolore.</a></h4>
                                <div class="post-info">26 March 2017</div>
                            </article>

                        </div>


                        <!-- Popular Tags -->
                        <div class="sidebar-widget popular-tags">
                            <div class="sidebar-title"><h3>Tags</h3></div>
                            <a href="#">Design</a>
                            <a href="#">Corporate</a>
                            <a href="#">Creative</a>
                            <a href="#">App</a>
                            <a href="#">Interfce</a>
                            <a href="#">Experience</a>
                            <a href="#">User</a>
                            <a href="#">Business</a>
                        </div>

                    </aside>


                </div>
                <!--Sidebar-->

            </div>
        </div>
    </div>
    
    <!--NewsLetter Section-->
    <section class="newsletter-section with-negative-margin">
    	<div class="auto-container">
        	<div class="outer-box">
            	<!--Heading-->
                <div class="sec-title centered">
                    <h2>Get Update</h2>
                </div>
                
                <!--Newsletter Style One-->
                <div class="newsletter-style-one">
                	<div class="desc-text">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia est deserunt mollit anim laborum. Sed perspiciatis unde omnis iste natus.</div>
                    
                    <form method="post" action="http://effortthemes.com/html/lirive/contact.html">
                        <div class="form-group">
                            <input type="email" name="text" value="" placeholder="Enter Your Email" required>
                            <button type="submit" class="theme-btn">Subscribe</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.applayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>